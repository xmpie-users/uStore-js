import React from 'react'
import Legacy from './Legacy'

const ProductDetails = (props) => {
  return <Legacy {...props}/>
}

export default ProductDetails
