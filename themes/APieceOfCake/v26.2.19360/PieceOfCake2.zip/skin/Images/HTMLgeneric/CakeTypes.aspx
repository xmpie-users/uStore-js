﻿<%@ Page Language="C#" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<script runat="server" language="c#" type="text/C#">
    protected void Page_Load(Object Src, EventArgs E)
    {
		var dict = new Dictionary<string, string>();
		dict.Add("Amandine", "Chocolate layered cake filled with chocolate, caramel and fondant cream.");
		dict.Add("Banana cake", "Banana cake is a cake prepared using banana as a primary ingredient and typical cake ingredients.");
		dict.Add("Banana bread", "A loaf of banana bread is moist and delicious, with loads of banana flavour!");
		dict.Add("Basbousa", "A traditional Egyptian sweet cake that is made of cooked semolina or farina soaked in simple syrup.");
		dict.Add("Baumkuchen", "A German variety of spit cake also popular in Japan. The characteristic rings, which resemble tree rings when sliced, give the cake its German name.");
		dict.Add("Black Forest cake", "Cherries, kirsch, and chocolate.");
		dict.Add("Blackout cake", "Chocolate cake with chocolate layers, chocolate sauce. AKA Death by Chocolate!");
		dict.Add("Blondie", "A rich, sweet dessert bar. It is made from flour, brown sugar, butter, eggs, baking powder, and vanilla.");
		dict.Add("Brownie", "A flat, baked square or bar developed in the United States at the end of the 19th century and popularized in both the US and Canada during the first half of the 20th century.");
		dict.Add("Bundt cake", "A cake that is baked in a Bundt pan, shaping it into a distinctive ring shape.");
		dict.Add("Butterfly cake", "A variant of the cupcake, also called 'fairy cake' for its fairy-like 'wings'.");
		dict.Add("Carrot cake", "Moist, dense, sweet cake made with carrots.");
		dict.Add("Cassata", "Cassata consists of round sponge cake moistened with fruit juices or liqueur and layered with ricotta cheese, candied peel, and a chocolate or vanilla filling similar to cannoli cream.");
		dict.Add("Cheesecake", "Thin base made from crushed biscuits, with a thicker top layer of soft cheese, eggs and sugar.");
		dict.Add("Chiffon cake", "Light, airy cake made with vegetable oil, eggs, sugar, and flour.");
		dict.Add("Chocolate cake", "An all-time favorite for Chocolate lovers!");
		dict.Add("Christmas cake", "Dried fruit such as sultanas or  raisins, cinnamon, treacle, cherries, and almond.");
		dict.Add("Coconut cake", "A cake frosted with a white frosting and covered in coconut flakes.");
		dict.Add("Cremeschnitte", "A vanilla and custard cream cake dessert popular in several central-European countries.");
		dict.Add("Croquembouche", "A French dessert consisting of choux pastry puffs piled into a cone and bound with threads of caramel.");
		dict.Add("Devil's food cake", "Chocolate or  cocoa, and baking soda.");
		dict.Add("Fruitcake", "Fruitcake is a cake made with candied and dried fruit, nuts, and spices, and soaked in spirits.");
		dict.Add("Hummingbird cake", "Banana, pineapple, pecan, vanilla, and spice.");
		dict.Add("Lamington", "White sponge squares soaked in chocolate sauce and rolled in desiccated coconut. Invented in Australia, but often incorrectly attributed to New Zealand.");
		dict.Add("Medovik", "A layer cake popular in Russia and other countries of the former Soviet Union.");
		dict.Add("Mille-feuille", "Also known as a Napoleon, is three layers of puff pastry alternating with two layers of pastry cream.");
		dict.Add("Mooncake", "A Chinese bakery product traditionally eaten during the Mid-Autumn Festival (Zhongqiujie).");
		dict.Add("Muffin", "An individual-sized quick bread product which can be sweet or savory.");
		dict.Add("Pancake", "Flat, round cake, made with eggs, milk, and plain flour.");
		dict.Add("Panettone", "An Italian cake featuring raisins, orange peel, and lemon peel.");
		dict.Add("Red velvet cake", "Sponge with red coloring and cocoa.");
		dict.Add("Soufflé", "Cream sauce or purée with beaten egg whites.");
		dict.Add("Swiss roll", "Jam and creamy filling in a thin sponge cake and rolled into a log. Developed in the UK, and not Switzerland as the name implies.");
		dict.Add("Tarte Tatin", "Apple or pear baked upside down! French and delicious!");
		dict.Add("Upside-down cake", "A cake that is baked with pineapple on the bottom that is flipped upside-down before serving.");
		dict.Add("Victoria sponge cake", "A cake that was named after Queen Victoria, who was known to enjoy a slice of the sponge cake with her afternoon tea.");

		var output = "";
		if (Request.QueryString["term"] != null)
		{
			var result = new Dictionary<string, string>();
			foreach(KeyValuePair<string, string> entry in dict)
			{
				if (entry.Key.ToLower().IndexOf(Request.QueryString["term"].ToLower()) > -1)
				{
					result.Add(entry.Key, entry.Value);
				}
			}
			foreach(KeyValuePair<string, string> entry in result)
			{
				output += "{\"label\":\"" + entry.Key + "\",\"value\":\"" + entry.Value + "\"},";
			}
			Response.Clear();
			Response.Write("[");
			Response.Write(output.Substring(0,output.Length - 1));
			Response.Write("]");
			Response.End();
		}
    }
</script>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
    </div>
    </form>
</body>
</html>
