import { t } from '$themelocalization'
import './LoadingDots.scss'

const LoadingDots = ({ className }) => {
  return (
    <div className={`loading-dots ${className ?? ''}`} role="status" aria-label={t('General.Loading')}>
      <div className='loading-dot'></div>
      <div className='loading-dot'></div>
      <div className='loading-dot'></div>
      <div className='loading-dot'></div>
    </div>
  )
}

export default LoadingDots
