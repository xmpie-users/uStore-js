import { useEffect, useRef } from 'react'

const useOnSubmitInvalid = (callback, formik) => {
  const handledCountRef = useRef(0)

  useEffect(() => {
    if (!formik.isValid && formik.submitCount > handledCountRef.current) {
      handledCountRef.current = formik.submitCount
      callback()
    }
  }, [callback, formik.isValid, formik.submitCount])
}

export default useOnSubmitInvalid
