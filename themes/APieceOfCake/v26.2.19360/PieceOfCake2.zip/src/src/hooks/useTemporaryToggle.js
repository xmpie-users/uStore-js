import { useCallback, useEffect, useRef, useState } from 'react'

const useTemporaryToggle = (delay) => {
  const [state, setState] = useState(false)

  const timeoutRef = useRef()
  useEffect(() => () => window.clearTimeout(timeoutRef.current), [])

  const setTemporaryState = useCallback(() => {
    window.clearTimeout(timeoutRef.current)
    setState(true)

    timeoutRef.current = window.setTimeout(() => setState(false), delay)
  }, [delay])

  return [state, setTemporaryState]
}

export default useTemporaryToggle
