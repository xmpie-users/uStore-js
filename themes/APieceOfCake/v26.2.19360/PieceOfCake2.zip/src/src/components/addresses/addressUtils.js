import { t } from '$themelocalization'

export const ADDRESS_TYPE = {
  BILLING: 2,
  SHIPPING: 1,
}

export const getAddressTypeLabel = (type) => {
  const isBilling = type === ADDRESS_TYPE.BILLING
  const translationKey = isBilling ? 'Address.Type.Billing' : 'Address.Type.Shipping'
  const fallback = isBilling ? 'Billing' : 'Shipping'

  return t(translationKey) || fallback
}

export const buildAddressLines = (address) => {
  if (!address) {
    return []
  }

  const {
    PersonName: personName,
    Company: company,
    Address1: address1,
    Address2: address2,
    City: city,
    State: stateObj = null,
    ZipCode: zipCode,
    Country: countryObj = null,
    Phone: phone,
    Email: email,
    Fax: fax,
    AddressReference: addressReference,
  } = address

  const state = stateObj?.Name ?? ""
  const country = countryObj?.Name ?? ""

  const lines = []
  if (personName) lines.push(personName)
  if (company) lines.push(company)
  if (address1) lines.push(address1)
  if (address2) lines.push(address2)
  if (city || state || zipCode) {
    const cityStateZip = [city, state, zipCode]
      .filter(Boolean)
      .join(', ')
    if (cityStateZip) lines.push(cityStateZip)
  }
  if (country) lines.push(country)
  if (phone) lines.push(phone)
  if (email) lines.push(email)
  if (fax) lines.push(fax)
  if (addressReference) lines.push(addressReference)
  return lines
}
