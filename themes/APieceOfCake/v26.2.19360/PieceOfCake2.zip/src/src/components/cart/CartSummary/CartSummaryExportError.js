import React, {useEffect} from 'react'
import { Icon } from '$core-components'
import './CartSummaryExportError.scss'


const CartSummaryExportError = ({model,  message }) => {
  useEffect(() => {
    setTimeout(() => {
      model?.openedList?.clearExportError()
    }, 5000)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])


  return (
    <div className="cart-summary-export-error" role="alert" aria-live="assertive">
      <Icon name="warning.svg" width="12px" height="12px" ariaHidden="true"/>{message}
    </div>
  )
}

export default CartSummaryExportError
