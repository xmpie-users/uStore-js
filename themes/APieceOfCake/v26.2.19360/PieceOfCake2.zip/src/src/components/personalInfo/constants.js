export const FormControlType = {
  TextInput: 1,
  DateTimePicker: 2,
  DropDownList: 3,
  Checkbox: 4,
}
