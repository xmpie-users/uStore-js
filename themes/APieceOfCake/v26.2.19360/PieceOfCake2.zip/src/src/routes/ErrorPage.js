import React from 'react'
import './ErrorPage.scss'
import {Icon, LinkAria} from '$core-components'
import urlGenerator from '$ustoreinternal/services/urlGenerator'
import {t} from '$themelocalization'
import Layout from "../components/layout";

const ErrorPage = (props) => {

    return <Layout {...props} classname="general-error">
        <div className="ng-error-page-wrapper">
            <div className="error-icon">
                <Icon name={'error_page_smile.svg'} width="100%x" height="100%"/>
            </div>
            <div className="error-page-main-text">
                {t("NGPages.GeneralError.Title")}
            </div>
            <div className="error-page-sub-text">
                {t("NGPages.GeneralError.SubText")}
            </div>
            <LinkAria to={urlGenerator.get({page: 'home'})}>
                <div
                    className="button button-primary truncate action-button">{t("NGPages.GeneralError.BackToHome")}</div>
            </LinkAria>

        </div>
    </Layout>
}

export default ErrorPage
