import React, { Component } from 'react'
import Legacy from './Legacy'

export default class OrderFinalStep extends Component {
  render () {
    return <Legacy {...this.props}/>
  }
}
