import React from 'react'
import Legacy from './Legacy'

const EmptyPage = (props) => {
  return <Legacy {...props}/>
}

export default EmptyPage
