const theme = {
  xs: '319px',
  sm: '575px',
  md: '767px',
  lg: '1199px',
  xl: '1919px',
}

export default theme