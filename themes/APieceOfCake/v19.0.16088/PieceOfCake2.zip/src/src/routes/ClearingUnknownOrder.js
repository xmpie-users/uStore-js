import React from 'react'
import Legacy from './Legacy'

const ClearingUnknownOrder = (props) => {
  return <Legacy {...props}/>
}

export default ClearingUnknownOrder