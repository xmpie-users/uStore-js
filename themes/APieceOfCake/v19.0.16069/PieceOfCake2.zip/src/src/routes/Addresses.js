import React from 'react'
import Legacy from './Legacy'

const Addresses = (props) => {
  return <Legacy {...props}/>
}

export default Addresses