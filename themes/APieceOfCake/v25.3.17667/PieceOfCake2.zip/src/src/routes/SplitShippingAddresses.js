import React from 'react'
import Legacy from './Legacy'

const SplitShippingAddresses = (props) => {
  return <Legacy {...props}/>
}

export default SplitShippingAddresses