export { default as EasyUploadPriceAndQuantity } from './EasyUploadPriceAndQuantity';
