import React from 'react'
import Legacy from './Legacy'

const ErrorPage = (props) => {
  return <Legacy {...props}/>
}

export default ErrorPage
