import React from 'react'
import Legacy from './Legacy'

const FileSubmission = (props) => {
  return <Legacy {...props} showScroll={true}/>
}

export default FileSubmission
