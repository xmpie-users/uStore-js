const fs = require('fs')
const path = require('path')

// HTTPS dev is opt-in by cert presence: `npm run cert` (mkcert) generates the local
// cert and the dev server then auto-serves HTTPS. No cert → HTTP. Paths overridable via env.
const getDevServerHttps = () => {
  const certDir = process.env.DEV_CERT_DIR || path.resolve(__dirname, '../.cert')
  const key = process.env.DEV_CERT_KEY || path.join(certDir, 'localhost-key.pem')
  const cert = process.env.DEV_CERT || path.join(certDir, 'localhost.pem')
  if (fs.existsSync(key) && fs.existsSync(cert)) {
    return { type: 'https', options: { key, cert } }
  }
  return undefined
}

module.exports = { getDevServerHttps }
