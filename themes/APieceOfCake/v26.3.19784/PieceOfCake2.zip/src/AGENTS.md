# uStore NG theme — rules for AI coding assistants

You are working inside a downloaded uStore NG theme. This file states which parts of this
package are a supported API and which are internal implementation details. Code that depends
on internals will break when the store owner upgrades uStore.

## Package layout

This file sits at the root of the theme's npm project, next to `package.json`. Every path below
is relative to it.

- `src/` — the React application. Your work happens here.
- `src/ustore-internal/` — framework code. Do not modify, move or delete anything in it.
- `webpack/`, `webpack-build.js`, `webpack-start.js`, `out/` — build configuration and build output.
- `../config.json` — theme manifest. Stable schema. Do not rename or remove fields.
- `../thumbnail.png` — keep this exact file name.
- `../skin/` — CSS for the legacy ASP.NET pages that are shown inside an iframe.

## Rules

1. **Extend, do not overwrite.** Add new files and new components. Change an existing base
   theme file only when there is no other way, and keep the change minimal. Every modified
   base file becomes a manual merge conflict at the next uStore upgrade.

2. **Do not touch `src/ustore-internal/`.** From it, use only the documented services:
   `themeContext`, `urlGenerator`, and `utils`. Anything else in that folder is
   internal, including anything you find there that is not listed on the General services page.

3. **Style through documented CSS variables and Custom CSS.** Do not write selectors that
   depend on the internal DOM structure or on generated class names. That markup changes
   between versions. To target a single page or item, use the stable hooks instead:
   `data-page` and `data-item-guid` on `<body>`, and `data-category-guid` /
   `data-product-guid` on the layout element. Variable list:
   https://github.com/XMPieLab/uStore-NG/wiki/Editing-CSS-Variables

4. **Use only documented `@ustore/core` methods.** Reference:
   https://github.com/XMPieLab/uStore-NG/wiki/uStoreProvider-UStoreProvider
   Do not read the internal Redux state directly and do not call methods that are not listed.

5. **Fetch server data through `UStoreProvider.api` or the public REST API** at
   `/ustorerestapi`. For data needed before a page renders, assign `getInitialProps` to the page
   component — `MyPage.getInitialProps = async ({ query }) => ({ ... })`. The component must be
   exported from `src/routes/index.js`; a file that is only present in `src/routes` is never called.

6. **Use widget slots for extension points.** Slot names are declared in `../config.json` under
   `customization.widgets.locations`. Do not inject markup into components you do not own.

7. **Do not edit build configuration** — `webpack/`, `webpack-build.js`, `webpack-start.js`,
   `package-lock.json`, `out/`, `dist/`.
   The `features` block of `../config.json` counts as build configuration: those are internal
   flags for the base theme's own components, read at build time. Leave the block as shipped,
   and do not add flags of your own to it.

8. **Routing and links.** This theme uses React Router. For internal links use the `LinkAria`
   component from `$core-components`, with the target URL produced by the `urlGenerator`
   service. Read routing information with the `react-router-dom` hooks (`useLocation`,
   `useNavigate`, `useParams`, `useSearchParams`). Write function components — the theme's own
   class components were migrated, and hooks are unavailable in class components.

9. **Localize user-facing strings.** Import the helper as a named export —
   `import { t } from '$themelocalization'` — and add keys to every locale file in
   `src/localizations`. Do not hardcode display text.

10. **If a supported extension point does not exist, stop and say so.** Ask the developer to
    request a new widget slot, CSS variable or API method from XMPie. Do not work around the
    gap by reaching into internals.

## Documentation index

Machine-readable sources. Each link returns the raw markdown of the page.

**Read first**

- Theme development overview — what a theme can and cannot change: https://raw.githubusercontent.com/wiki/XMPieLab/uStore-NG/Theme-development-overview.md
- Theme file structure — package layout and folder aliases: https://raw.githubusercontent.com/wiki/XMPieLab/uStore-NG/Theme-file-structure.md

**Coding a theme**

- uStore library — the `@ustore/core` package and `UStoreProvider`: https://raw.githubusercontent.com/wiki/XMPieLab/uStore-NG/uStore-library.md
- uStoreProvider reference — the supported API surface; anything absent from it is internal: https://raw.githubusercontent.com/wiki/XMPieLab/uStore-NG/uStoreProvider-UStoreProvider.md
- Working with REST API — API calls and `getInitialProps`: https://raw.githubusercontent.com/wiki/XMPieLab/uStore-NG/Working-with-REST-API.md
- Accessing uStore data — the data model exposed through the state object: https://raw.githubusercontent.com/wiki/XMPieLab/uStore-NG/Accessing-uStore-data.md
- Managing custom state — storing your own data across the application: https://raw.githubusercontent.com/wiki/XMPieLab/uStore-NG/Managing-custom-state.md
- General services — `urlGenerator` and the other supported services: https://raw.githubusercontent.com/wiki/XMPieLab/uStore-NG/General-services.md
- Working with localizations — adding and using localized strings: https://raw.githubusercontent.com/wiki/XMPieLab/uStore-NG/Working-with-localizations.md
- Adding a new page — creating a route and linking to it: https://raw.githubusercontent.com/wiki/XMPieLab/uStore-NG/Adding-a-new-page.md
- Adding a component — adding a component to an existing page: https://raw.githubusercontent.com/wiki/XMPieLab/uStore-NG/Adding-a-component.md
- Adding an external package — installing third-party npm dependencies: https://raw.githubusercontent.com/wiki/XMPieLab/uStore-NG/Adding-an-external-package.md

**Styling**

- Editing CSS variables — the canonical variable list; variables not listed there are internal: https://raw.githubusercontent.com/wiki/XMPieLab/uStore-NG/Editing-CSS-Variables.md
- Editing the CSS — the Custom CSS panel of the theme editor: https://raw.githubusercontent.com/wiki/XMPieLab/uStore-NG/Editing-the-CSS.md
- Editing fonts — replacing theme fonts: https://raw.githubusercontent.com/wiki/XMPieLab/uStore-NG/Editing-fonts.md
- Customizing a skin — styling the legacy pages shown in an iframe: https://raw.githubusercontent.com/wiki/XMPieLab/uStore-NG/Customizing-a-skin.md
- Theme customization overview — theme editor and CSS precedence order: https://raw.githubusercontent.com/wiki/XMPieLab/uStore-NG/Theme-customization-overview.md

**Shipping and upgrading**

- Publishing the theme — building a package and uploading it: https://raw.githubusercontent.com/wiki/XMPieLab/uStore-NG/Publishing-the-theme.md
- Upgrading a custom theme — moving onto a new uStore version: https://raw.githubusercontent.com/wiki/XMPieLab/uStore-NG/Upgrading-a-Custom-Theme.md
- Customizing the theme editor — exposing your own variables as editor controls: https://raw.githubusercontent.com/wiki/XMPieLab/uStore-NG/Customizing-the-Theme-Editor.md

**Extending uStore beyond the theme**

- Widgets — adding functionality at defined slots: https://raw.githubusercontent.com/wiki/XMPieLab/uStore-NG/Widgets.md
- Input control development guide — custom product input controls: https://raw.githubusercontent.com/wiki/XMPieLab/uStore-NG/Input-Control-Development-Guide.md
- Using uStore as a web component — embedding the storefront in another site: https://raw.githubusercontent.com/wiki/XMPieLab/uStore-NG/Using-uStore-as-a-web-component.md
- Extensibility overview — tax, order approval, manufacturer and cart export webhooks: https://raw.githubusercontent.com/wiki/XMPieLab/uStore-NG/uStore-NG-Extensibility.md

**Optional — skip these if context is limited**

- Theme tips and tricks — practical patterns for theme code: https://raw.githubusercontent.com/wiki/XMPieLab/uStore-NG/Theme-tips-and-tricks.md
- Migration from legacy to NG — moving a pre-NG store onto theme technology: https://raw.githubusercontent.com/wiki/XMPieLab/uStore-NG/Migration-from-Legacy-to-NG.md
- Themes and snippets — sample themes and code snippets: https://raw.githubusercontent.com/wiki/XMPieLab/uStore-NG/Themes-and-Snippets-Overview.md

## Before you finish

- No new or modified files under `src/ustore-internal/`
- No CSS selectors built from inspecting the rendered DOM — page and item targeting goes through the `data-page` and `data-*-guid` hooks
- No calls to `@ustore/core` members that are absent from the reference
- All user-facing strings go through the localization files
- The list of base theme files you modified is short, and you can name a reason for each
