import { UStoreProvider } from '@ustore/core'
import themeContext from '$ustoreinternal/services/themeContext'

let prefetched = null

export const prefetchProduct = (friendlyID) => {
  const promise = (async () => {
    const productID = await UStoreProvider.api.products.getProductIDByFriendlyID(friendlyID, { suppressGlobalError: true })
    return await UStoreProvider.api.products.getProductByID(productID, undefined, { suppressGlobalError: true })
  })()
  promise.catch(() => {})
  prefetched = { storeID: themeContext.get('storeID'), friendlyID: String(friendlyID), promise }
}

export const takePrefetchedProduct = (friendlyID) => {
  if (prefetched && prefetched.storeID === themeContext.get('storeID') && prefetched.friendlyID === String(friendlyID)) {
    const { promise } = prefetched
    prefetched = null
    return promise.catch(() => null)
  }
  return null
}

export const clearPrefetchedProduct = () => {
  prefetched = null
}
