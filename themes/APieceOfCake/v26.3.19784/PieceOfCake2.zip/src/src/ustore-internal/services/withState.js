import React from 'react'
import { UStoreProvider } from '@ustore/core'
import deepcopy from 'deepcopy'

export const withState = (WrappedComponent) => {
  const ConnectedComponent = (props) => {
    const preRender = WrappedComponent.preRender
    const state = UStoreProvider ? UStoreProvider.state.get() : {}
    const preRenderedState = preRender ? preRender(deepcopy(state)) : state
    return <WrappedComponent {...props} state={preRenderedState} customState={preRenderedState.customState}/>
  }

  return ConnectedComponent
}
