const fs = require('fs')
const path = require('path')
const webpack = require('webpack')
const TerserPlugin = require('terser-webpack-plugin')

const themesRoot = path.resolve(__dirname, '..', '..', '..')
const entryDir = path.join(themesRoot, 'node_modules', '.cache', 'react-global')
const entryFile = path.join(entryDir, 'entry.js')
const outputDir = path.join(themesRoot, 'src', 'ustore-internal', 'static')
const outputFileName = 'react.global.js'

// require, not import: window.React must be the same CommonJS exports object the
// removed UMD build exposed, not an ES module namespace with frozen properties
const entrySource = `const React = require('react')
const ReactDOM = require('react-dom')
const ReactDOMClient = require('react-dom/client')
const PropTypes = require('prop-types')

const ReactDOMGlobal = Object.assign({}, ReactDOM, ReactDOMClient)
ReactDOMGlobal.default = ReactDOMGlobal

window.React = React
window.ReactDOM = ReactDOMGlobal
window.PropTypes = PropTypes
`

const buildReactGlobal = () => {
	const reactVersion = require(path.join(
		themesRoot,
		'node_modules',
		'react',
		'package.json'
	)).version

	fs.mkdirSync(entryDir, { recursive: true })
	fs.writeFileSync(entryFile, entrySource)

	const compiler = webpack({
		mode: 'production',
		target: 'web',
		context: themesRoot,
		entry: entryFile,
		output: {
			path: outputDir,
			filename: outputFileName,
			iife: true,
		},
		devtool: false,
		performance: { hints: false },
		optimization: {
			// output goes into a source folder, so keep the React license notice
			// inline rather than emitting a react.global.js.LICENSE.txt beside it
			minimizer: [
				new TerserPlugin({
					extractComments: false,
					terserOptions: { format: { comments: /@license/i } },
				}),
			],
		},
	})

	return new Promise((resolve, reject) => {
		compiler.run((err, stats) => {
			const finish = (error) => {
				compiler.close(() => (error ? reject(error) : resolve()))
			}

			if (err) {
				return finish(err)
			}

			if (stats.hasErrors()) {
				console.error(stats.toString({ colors: true, all: false, errors: true }))
				return finish(new Error('react.global.js build failed'))
			}

			console.log(
				`Generated static/react.global.js (React ${reactVersion}, ${Math.round(
					fs.statSync(path.join(outputDir, outputFileName)).size / 1024
				)} KB)`
			)
			finish()
		})
	})
}

if (require.main === module) {
	buildReactGlobal().catch((err) => {
		console.error(err.message)
		process.exit(1)
	})
}

module.exports = buildReactGlobal
