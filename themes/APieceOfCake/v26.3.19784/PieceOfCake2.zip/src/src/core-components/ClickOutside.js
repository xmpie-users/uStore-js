import { useEffect, useRef } from 'react'

const ClickOutside = ({ className, trigger, children }) => {
  const wrapperRef = useRef(null)
  const triggerRef = useRef(trigger)
  triggerRef.current = trigger

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
        triggerRef.current(event)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  return <div className={className} ref={wrapperRef}>{children}</div>
}

export default ClickOutside
