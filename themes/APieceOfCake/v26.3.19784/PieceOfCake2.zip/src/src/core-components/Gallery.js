/**
 * @function Gallery - a component which displays an array of items (childrens)
 *
 * @param {String} [title] - The main title at the top of the component
 * @param {String} [seeAllUrl] - The link to the full gallery page
 * @param {Number} [gridRows] - The number of rows (default: 2)
 * @param {Component} children - The children components
 */

import React, { useLayoutEffect, useReducer, useRef } from 'react'
import { Link } from 'react-router-dom'
import { t } from '$themelocalization'
import './Gallery.scss'

const DEFAULT_GRID_ROWS = 2

const Gallery = ({ title, seeAllUrl, gridRows, children }) => {
  const galleryRef = useRef(null)
  const [, forceRender] = useReducer((x) => x + 1, 0)

  // layout effect so items-per-row is measured and applied before the first paint
  useLayoutEffect(() => {
    forceRender()
    window.addEventListener('resize', forceRender)
    return () => window.removeEventListener('resize', forceRender)
  }, [])

  if (!children) {
    return null
  }

  const getItemsInRow = () => {
    if (!galleryRef.current) {
      return 0
    }
    const basis = window.getComputedStyle(galleryRef.current).getPropertyValue('--flex-basis').replace('%', '')
    return Math.floor(100 / parseInt(basis))
  }

  const itemsToShow = getItemsInRow() * parseInt(gridRows || DEFAULT_GRID_ROWS)

  const filteredChildren = React.Children.map(children, (child, i) => {
    if (i < itemsToShow) return child
    return null
  })

  const showSeeAll = seeAllUrl && React.Children.count(filteredChildren) < React.Children.count(children)

  return (
    <div className="gallery" ref={galleryRef}>
      <div className="top">
        {
          title && <div className='main-title'>{title}</div>
        }
        {
          showSeeAll &&
          <Link className="see-all" to={seeAllUrl}>{t('Gallery.See_all_products')}</Link>
        }
      </div>
      <div className="main">
        { filteredChildren }
      </div>
      {
        showSeeAll &&
        <div className="bottom">
          <Link className="button-secondary" to={seeAllUrl}>{t('Gallery.See_all_products')}</Link>
        </div>
      }
    </div>
  )
}

export default Gallery
