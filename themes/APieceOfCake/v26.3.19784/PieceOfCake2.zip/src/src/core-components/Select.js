import React, { useContext, useRef, useState, useEffect } from 'react'
import { Button, ListBox, ListBoxItem, Popover, Select as AriaSelect, SelectValue } from 'react-aria-components'
import { useClickOutside } from '$themehooks'
import { RootDocumentContext } from '$themeservices'
import Icon from './Icon'
import './Select.scss'

const Select = ({
  items,
  selectedKey,
  onSelectionChange,
  isDisabled,
  placeholder,
  ariaLabel,
  ariaLabelledBy,
  ariaDescribedBy,
  isInvalid,
  className = '',
  triggerClassName = '',
  popoverClassName = '',
  optionClassName = '',
  portalSelector,
  renderItem,
}) => {
  const wrapperRef = useRef(null)
  const popoverRef = useRef(null)
  const [portalContainer, setPortalContainer] = useState(null)
  const [isOpen, setIsOpen] = useState(false)
  const { rootElement } = useContext(RootDocumentContext)()

  useClickOutside(popoverRef, () => setIsOpen(false), rootElement)

  useEffect(() => {
    if (!portalSelector || !wrapperRef.current) return
    setPortalContainer(wrapperRef.current.closest(portalSelector) || null)
  }, [portalSelector])

  return (
    <AriaSelect
      ref={wrapperRef}
      className={`select-field ${className}`}
      selectedKey={selectedKey}
      onSelectionChange={onSelectionChange}
      isDisabled={isDisabled}
      isInvalid={isInvalid}
      isOpen={isOpen}
      onOpenChange={setIsOpen}
      aria-label={ariaLabelledBy ? undefined : ariaLabel}
      aria-labelledby={ariaLabelledBy}
    >
      <Button type="button" className={`select-field-trigger ${triggerClassName}`} aria-describedby={ariaDescribedBy}>
        <SelectValue placeholder={placeholder}/>
        <Icon name="arrowDown.svg" width="10px" height="10px" ariaHidden="true"/>
      </Button>
      <Popover
        ref={popoverRef}
        className={`select-field-popover ${popoverClassName}`}
        minWidth="trigger-width"
        isNonModal
        shouldCloseOnInteractOutside={() => false}
        UNSTABLE_portalContainer={portalContainer || undefined}
      >
        <ListBox className="select-field-listbox" items={items}>
          {(item) => (
            <ListBoxItem id={item.id} textValue={item.name} className={`select-field-option ${optionClassName}`}>
              {renderItem ? renderItem(item) : item.name}
            </ListBoxItem>
          )}
        </ListBox>
      </Popover>
    </AriaSelect>
  )
}

export default Select
