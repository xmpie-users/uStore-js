import React from 'react'
import './CrossFade.scss'

/**
 * @function CrossFade - cross-fades between its children, showing one at a time.
 *
 * Replaces reactstrap's Carousel/CarouselItem, which render react-transition-group's
 * Transition without a nodeRef and therefore call the removed ReactDOM.findDOMNode.
 * The directional slide transition is intentionally dropped for a cross-fade — both
 * consumers already own their active index, arrows and swipe handling.
 *
 * @param {number} activeIndex - index of the child to show
 */
const CrossFade = ({ activeIndex, children }) => (
  <div className="cross-fade">
    {React.Children.map(children, (child, index) => (
      <div
        className={`cross-fade-slide${index === activeIndex ? ' is-active' : ''}`}
        aria-hidden={index !== activeIndex}
      >
        {child}
      </div>
    ))}
  </div>
)

export default CrossFade
