import { useRef } from 'react'
import { useOverlayTriggerState } from 'react-stately';

export const PopoverAria = ({ children, state, className, ...props }) => {
  const popoverRef = useRef(null);

  let overlayState = useOverlayTriggerState(props);
  if (state) {
    overlayState = state;
  }

  if (!overlayState.isOpen) {
    return null;
  }

  return (
    <div className={className} ref={popoverRef}>
      <div className="underlay"/>
      {children}
    </div>
  );
}
