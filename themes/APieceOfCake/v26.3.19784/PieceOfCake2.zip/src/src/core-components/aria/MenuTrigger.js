import React, { useState, useEffect } from 'react';

export const MenuTrigger = ({ children, isOpen, onOpenChange }) => {
  const [open, setOpen] = useState(isOpen)

  useEffect(() => {
    setOpen(isOpen)
  }, [isOpen])

  return <div onClick={(e) => {
    onOpenChange(!open);
    setOpen(!open)
  }}>
    {children}
  </div>
}
