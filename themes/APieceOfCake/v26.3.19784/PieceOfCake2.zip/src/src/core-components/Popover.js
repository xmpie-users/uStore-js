import React from 'react'
import { Popover as ReactstrapPopover } from 'reactstrap'

// reactstrap 9.2.3 supplies these through defaultProps on a function component, which
// React 19 drops silently. placementPrefix is the load-bearing one — it produces the
// bs-popover-* classes the arrow and positioning styles depend on.
// props spread last so a call site can still override any of them.
const Popover = (props) => (
  <ReactstrapPopover
    placement="right"
    placementPrefix="bs-popover"
    trigger="click"
    offset={[0, 8]}
    {...props}
  />
)

export default Popover
