/**
 * @function Slider - a component which displays items in a circular way
 *
 * @param {boolean} multi - defined: multiple items in a page, not-defined: single item
 * @param {Component} children - The children components
 */

import { useEffect, useLayoutEffect, useRef } from 'react'
import { Swipeable } from '$core-components'
import Icon from './Icon'
import './Slider.scss'

/**
 * Direction mapping for the react-swipeable library
 */
const RIGHT = '-1'
const LEFT = '+1'

/**
 * Transition speed
 */
const TRANSITION_SPEED = 500

/**
 * arrows consts
 */
const ARROW_MARGIN = 20
const ARROW_WIDTH = 30
const ARROW_HEIGHT = 30

const itemsArraysEqual = (arr1, arr2) => {
  if (arr1.length !== arr2.length) return false
  return arr1.every((value, index) => value === arr2[index])
}

const Slider = ({ children, multi, ariaAttrs = {} }) => {
  const sliderRef = useRef(null)
  const arrowsActive = useRef(true)
  // render does not depend on any of this — a mutable bag mirrors the old instance state
  const state = useRef({
    children: [], // Holds a copy of each item
    childrenLength: 0, // Number of items
    currentPosition: 0, // Current "left" value of the slider
    currentPage: 0, // Current page
    displayedItems: 0, // Number of items in a page
    lastClonedItemRight: null, // Index (children) of the last item on the right section
    lastClonedItemLeft: null, // Index (children) of the last item on the left section
    lastItemWidth: null // Used to check if there was a change in breakpoint
  }).current

  const getCssContent = (key) => {
    let content = window.getComputedStyle(sliderRef.current, ':after').getPropertyValue('content')
    content = content.replace(new RegExp('"', 'g'), '').replace(new RegExp('`', 'g'), '"')

    if (content === 'none' || content === '') {
      return null
    }

    try {
      content = JSON.parse(content)
      return content[key]
    } catch (e) {
      console.error(e)
    }
  }

  const getItemsInRow = () => getCssContent('items')

  const setButtons = () => {
    const slider = sliderRef.current
    if (slider && slider.parentNode) {
      const sliderClientWidth = slider.clientWidth

      const leftBtn = slider.parentNode.querySelector(`.left-btn`)
      const rightBtn = slider.parentNode.querySelector(`.right-btn`)

      if (leftBtn && rightBtn) {
        if (arrowsActive.current) {
          leftBtn.style.visibility = 'visible'
          rightBtn.style.visibility = 'visible'
          rightBtn.style.left = `${sliderClientWidth - ARROW_WIDTH - ARROW_MARGIN}px`
        } else {
          leftBtn.style.visibility = 'hidden'
          rightBtn.style.visibility = 'hidden'
        }
      }
    }
  }

  const setDotsPosition = () => {
    const dots = sliderRef.current.parentNode.querySelector(`div.dots`)
    if (!dots) {
      return
    }
    dots.style.top = '-100px'
  }

  const initDots = (childrenLength) => {
    const dots = sliderRef.current.parentNode.querySelector(`div.dots`)
    if (!dots) { return }

    dots.innerHTML = ''

    for (let i = 0; i < childrenLength; i++) {
      const dot = document.createElement('div')
      dot.className = 'dot'
      dots.appendChild(dot)
    }

    dots.childNodes[0].setAttribute('class', 'dot active')
  }

  const setActiveDot = (isForward) => {
    const dots = sliderRef.current.parentNode.querySelector(`div.dots`)
    if (!dots) {
      return
    }

    let currentPage = state.currentPage
    const childrenLength = state.childrenLength

    if (isForward) {
      currentPage += 1
      if (currentPage === childrenLength) {
        currentPage = 0
      }
    } else {
      currentPage -= 1
      if (currentPage === -1) {
        currentPage = childrenLength - 1
      }
    }

    state.currentPage = currentPage

    for (let i = 0; i < dots.childNodes.length; i++) {
      dots.childNodes[i].setAttribute('class', 'dot')
    }
    dots.childNodes[currentPage].setAttribute('class', 'dot active')
  }

  const setSliderPosition = (isForward, isTransition, displayedItems) => {
    const slider = sliderRef.current
    const itemWidth = slider.childNodes[0].clientWidth
    const sliderWidth = displayedItems * itemWidth
    let currentPosition = state.currentPosition

    if (isForward) {
      currentPosition -= sliderWidth
    } else {
      currentPosition += sliderWidth
    }

    if (isTransition) {
      slider.style.transition = `left ${TRANSITION_SPEED}ms`
    } else {
      slider.style.transition = `none`
    }

    const left = `${currentPosition}px`
    slider.style.left = left

    state.currentPosition = currentPosition
  }

  const createInitRightSection = (displayedItems, children) => {
    const slider = sliderRef.current
    const clonedNodesToAppend = []

    // Clone all first items that need to filled the gap of items per row
    const itemsTofill = displayedItems - children.length % displayedItems

    for (let i = 0; i < itemsTofill; i++) {
      if (!children[i]) {
        continue
      }

      clonedNodesToAppend.push(children[i].cloneNode(true))

      if (i === itemsTofill - 1) {
        state.lastClonedItemRight = i
      }
    }

    // Append the clonedNodesToAppend after the last item
    for (let i = 0; i < clonedNodesToAppend.length; i++) {
      slider.append(clonedNodesToAppend[i])
    }
  }

  const createInitLeftSection = (displayedItems, children) => {
    const slider = sliderRef.current
    const clonedNodesToPrepend = []

    // Clone all last items per row child nodes
    let j = displayedItems
    for (let i = children.length - 1; i >= 0; i--) {
      clonedNodesToPrepend.push(children[i].cloneNode(true))
      j--
      if (j === 0) {
        state.lastClonedItemLeft = i
        break
      }
    }

    // Prepend the clonedNodesToPrepend before the first item
    for (let i = 0; i < clonedNodesToPrepend.length; i++) {
      const firstItem = slider.firstChild
      slider.insertBefore(clonedNodesToPrepend[i], firstItem)
    }
  }

  const reorderItems = (isForward) => {
    const slider = sliderRef.current
    let lastClonedItem = (isForward) ? state.lastClonedItemRight : state.lastClonedItemLeft

    if (lastClonedItem === null) {
      return
    }

    if (isForward) {
      const clonedNodesToAppend = []
      let j = lastClonedItem + 1

      // Clone all items of the next row
      for (let i = 0; i < state.displayedItems; i++) {
        if (j === state.children.length) {
          j = 0
        }
        clonedNodesToAppend.push(state.children[j].cloneNode(true))

        if (i === state.displayedItems - 1) {
          state.lastClonedItemRight = j
          lastClonedItem = j
        }
        j++
      }

      // Append the clonedNodesToAppend after the last item
      for (let i = 0; i < clonedNodesToAppend.length; i++) {
        slider.append(clonedNodesToAppend[i])
      }

      // Remove trailing row
      for (let i = 0; i < state.displayedItems; i++) {
        slider.childNodes[0].remove()
      }

      // Find the last left cloned item
      j = lastClonedItem - 1
      for (let i = 0; i < state.displayedItems; i++) {
        if (j === -1) {
          j = state.children.length - 1
        }

        if (i === state.displayedItems - 1) {
          state.lastClonedItemLeft = j
        }
        j--
      }

      setSliderPosition(false, false, state.displayedItems)
    } else {
      const children = slider.childNodes
      const clonedNodesToPrepend = []
      let j = lastClonedItem - 1

      // Clone all items of the next row
      for (let i = 0; i < state.displayedItems; i++) {
        if (j === -1) {
          j = state.children.length - 1
        }

        clonedNodesToPrepend.push(state.children[j].cloneNode(true))

        if (i === state.displayedItems - 1) {
          state.lastClonedItemLeft = j
          lastClonedItem = j
        }
        j--
      }

      // Append the clonedNodesToPrepend after the last item
      for (let i = 0; i < clonedNodesToPrepend.length; i++) {
        const firstItem = children[0]
        slider.insertBefore(clonedNodesToPrepend[i], firstItem)
      }

      // Remove last row
      for (let i = 0; i < state.displayedItems; i++) {
        slider.childNodes[slider.childNodes.length - 1].remove()
      }

      // Find the last right cloned item
      j = lastClonedItem + 1
      for (let i = 0; i < state.displayedItems; i++) {
        if (j === state.children.length) {
          j = 0
        }

        if (i === state.displayedItems - 1) {
          state.lastClonedItemRight = j
        }
        j++
      }

      setSliderPosition(true, false, state.displayedItems)
    }
  }

  const slide = (isForward, isReorder) => {
    if (!arrowsActive.current) {
      return
    }

    setSliderPosition(isForward, true, state.displayedItems)

    setTimeout(() => {
      if (isReorder) {
        reorderItems(isForward)
      }
    }, TRANSITION_SPEED)

    setActiveDot(isForward)
  }

  const onResize = () => {
    const slider = sliderRef.current

    if (!slider || !multi || !arrowsActive.current) {
      return
    }

    const children = slider.childNodes
    const displayedItems = Math.round(slider.clientWidth / children[0].clientWidth)

    const lastItemWidth = state.lastItemWidth
    let addPosition = 0

    if (lastItemWidth !== children[0].clientWidth) {
      if (lastItemWidth > children[0].clientWidth) {
        addPosition -= children[0].clientWidth
      } else {
        addPosition += children[0].clientWidth
      }
    }

    const currentPosition = -slider.clientWidth + addPosition
    slider.style.left = `${currentPosition}px`

    state.currentPosition = currentPosition
    state.displayedItems = displayedItems
    state.lastItemWidth = lastItemWidth

    // this path writes refs only, so it never re-renders and the layout effect below cannot fire
    setButtons()
  }

  const setInitState = () => {
    const slider = sliderRef.current
    if (!(slider && slider.childNodes)) {
      return
    }

    const children = slider.childNodes
    const itemsInRow = getItemsInRow() || 1
    const clonedNodes = []
    const childrenLength = state.childrenLength || children.length

    state.childrenLength = childrenLength

    // On init (mount) - Clone all children
    if (state.children.length === 0) {
      for (let i = 0; i < childrenLength; i++) {
        let clonedEl = children[i].cloneNode(true)
        clonedEl.setAttribute('aria-hidden', 'true')
        clonedEl.setAttribute('tabindex', '-1')
        clonedNodes.push(clonedEl)
      }
      state.children = clonedNodes
    }
    // On Resize - clear slider, fill with children, set left to position zero
    else {
      slider.innerHTML = ''

      for (let i = 0; i < state.children.length; i++) {
        slider.appendChild(state.children[i])
      }

      slider.style.left = '0px'
    }

    if (childrenLength <= itemsInRow) {
      slider.style.justifyContent = 'center'
      arrowsActive.current = false
      return
    }

    slider.style.removeProperty('justify-content');
    arrowsActive.current = true

    // Calculate number of items in a row
    const displayedItems = Math.round(slider.clientWidth / children[0].clientWidth)

    state.displayedItems = displayedItems
    state.lastItemWidth = children[0].clientWidth

    createInitRightSection(displayedItems, clonedNodes)
    createInitLeftSection(displayedItems, clonedNodes)
    setSliderPosition(true, false, displayedItems)
    setDotsPosition()
    initDots(childrenLength)
  }

  const resetAndInit = () => {
    setTimeout(() => {
      state.children = []
      state.childrenLength = 0
      state.currentPosition = 0
      state.currentPage = 0
      state.displayedItems = 0
      state.lastClonedItemRight = null
      state.lastClonedItemLeft = null
      state.lastItemWidth = null
      setInitState()
    })
  }

  const onSwiped = (direction) => {
    const isForward = direction !== RIGHT
    slide(isForward, true)
  }

  useEffect(() => {
    // Some initializations code
    setInitState()

    // On screen resizing
    const handleResize = () => onResize()
    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [])

  // no dependency array on purpose: the class version called setButtons() from render(),
  // so arrow visibility and the width-dependent right-btn offset re-converged on every render
  useLayoutEffect(() => {
    setButtons()
  })

  const prevChildrenRef = useRef(null)
  useEffect(() => {
    const prevChildren = prevChildrenRef.current
    prevChildrenRef.current = children
    if (prevChildren === null || !children) {
      return
    }

    if (prevChildren.length !== children.length) {
      resetAndInit()
      return
    }

    if (prevChildren.length > 0 && children.length > 0) {
      const getItemIdentifier = (item, index) => {
        return item.props?.model?.FriendlyID || item.key || `item-${index}`
      }

      const prevItems = prevChildren.map(getItemIdentifier)
      const currentItems = children.map(getItemIdentifier)

      if (!itemsArraysEqual(prevItems, currentItems)) {
        resetAndInit()
      }
    }
  })

  if (!children) {
    return null
  }

  return (
    <Swipeable
      trackMouse
      preventDefaultTouchmoveEvent
      onSwipedLeft={() => children.length > 1 && onSwiped(LEFT)}
      onSwipedRight={() => children.length > 1 && onSwiped(RIGHT)}
    >
      <section
        className={`slider-wrapper${multi ? '-multi' : '-single'}`}
        {...ariaAttrs}
      >
        <div className="slider" ref={sliderRef}>
          {children}
        </div>
        <div className="arrows left-btn" onClick={() => slide(false, true)}>
          <Icon name="arrow.svg" width={`${ARROW_WIDTH}px`} height={`${ARROW_HEIGHT}px`} className="left-arrow-icon" />
        </div>
        <div className="arrows right-btn" onClick={() => slide(true, true)}>
          <Icon name="arrow.svg" width={`${ARROW_WIDTH}px`} height={`${ARROW_HEIGHT}px`} className="right-arrow-icon" />
        </div>
        {!multi && <div className="dots" aria-hidden="true" />}
      </section>
    </Swipeable>
  )
}

export default Slider
