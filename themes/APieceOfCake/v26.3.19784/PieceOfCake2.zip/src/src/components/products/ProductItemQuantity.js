/**
 * A component to display quantity input based on quantity data model
 *
 * @param {function} onQuantityChange(value, isValid) - a callback fired when quantity was changed.
 * @param {object} productModel
 * @param {object} orderModel
 * @param {supportsInventory} boolean
 */

import { useState } from 'react'
import './ProductItemQuantity.scss'
import BaseQuantity from './BaseQuantity'
import { t } from '$themelocalization'
import { Tooltip } from 'reactstrap'

const ProductItemQuantity = ({ productModel, orderModel, onQuantityChange, supportsInventory }) => {
  const [errorMessage, setErrorMessage] = useState('')
  const [showErrorTooltip, setShowErrorTooltip] = useState(false)
  const [errorTooltipTarget, setErrorTooltipTarget] = useState('')

  const getValidationErrorMessage = (value) => {
    const { Configuration: { Quantity: { Minimum, Maximum } }, Inventory } = productModel

    const inventory = supportsInventory && Inventory ? Inventory.Quantity : null

    if (value === null || value === undefined || isNaN(value)) {
      return <span className='validation-required'>{t('KitQuantity.Validation_required')}</span>
    }

    if (Minimum && Number(value) < Minimum) {
      return <span className='validation-minimum'>{t('KitQuantity.Validation_minimum', { MinimumQuantity: Minimum })}</span>
    }

    if (Maximum && Number(value) > Maximum) {
      return <span className='validation-maximum'>{t('KitQuantity.Validation_maximum', { MaximumQuantity: Maximum })}</span>
    }

    if (inventory && Number(value) > inventory && !Inventory.AllowOutOfStockPurchase) {
      return <span className='validation-inventory'>{t('KitQuantity.Validation_inventory', { InventoryQuantity: inventory })}</span>
    }

    return null
  }

  const onChange = (e) => {
    const value = parseInt(e.target.value)
    const message = getValidationErrorMessage(value)
    setErrorMessage(message)
    setShowErrorTooltip(!!message)
    setErrorTooltipTarget(e.target.id)

    // send new value and isValid to parent.
    onQuantityChange(value, !message)
  }

  const { Configuration: { Quantity }, ID } = productModel

  // if no Configuration dont show anything
  if (!Quantity) {
    return null
  }
  const additionalClassName = errorMessage ? 'not-valid' : ''
  const targetExist = document.getElementById(`${errorTooltipTarget}`)

  return (<div className="product-item-quantity">
    <BaseQuantity
      quantityConfig={Quantity}
      additionalClassName={additionalClassName}
      quantity={orderModel.Quantity}
      id={ID}
      onChange={onChange}
      showMinimalDisplay={true}
    />
    {
      showErrorTooltip && targetExist &&
      <Tooltip placement='bottom' isOpen={true} target={errorTooltipTarget}
        className="quantity-error-tooltip bs-tooltip-bottom">
        {errorMessage}
      </Tooltip>
    }
  </div>)
}

export default ProductItemQuantity
