import React, { useContext, useId, useState } from 'react'
import {
  Dropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Input,
} from 'reactstrap'
import { RootDocumentContext } from '$themeservices'
import { SelectorArrow } from '$core-components'

import './UEditDropDown.scss'

export const UEditDropDown = ({
  direction,
  items,
  selectedValue,
  onChange,
  searchable,
  searchPlaceholder,
  disabled,
  customArrow,
  ...args
}) => {
  const { documentRoot } = useContext(RootDocumentContext)()
  const [dropdownOpen, setDropdownOpen] = useState(false)
  const [otherValue, setOtherValue] = useState('')
  const instanceToken = `uedit-drop-down-${useId().replace(/:/g, '')}`

  // Same shadow-DOM outside-click guard as core-components/DropDown.js — see the
  // comment there for why the token is per-instance and why native events only
  const toggle = (e) => {
    const isNativeProbe = e && !('nativeEvent' in e)
    if (
      documentRoot !== document &&
      isNativeProbe &&
      e.composedPath().some((node) => node?.classList?.contains?.(instanceToken))
    ) {
      return
    }
    setDropdownOpen((prevState) => !prevState)
  }
  return (
    <Dropdown isOpen={dropdownOpen} toggle={toggle} direction={direction} className={`uedit-drop-down ${instanceToken}`}>
      <DropdownToggle disabled={disabled} caret>
        <SelectorArrow/>
        {selectedValue?.name ?
        <span>{selectedValue.name}</span> :
        <span> {otherValue ? `${otherValue} pt` : ''}</span>}
      </DropdownToggle>
      <DropdownMenu {...args} >
        {items.map((item, index) => {
          return <DropdownItem key={index}
                               onKeyDown={() => !item.disabled && onChange(item)}
                               onClick={() => !item.disabled && onChange(item)}
                               active={selectedValue?.value === item.value}
                               disabled={item.disabled}
          >
            <span>{item.name}</span>
          </DropdownItem>
        })}
        <DropdownItem key={items.length} onClick={() => onChange({ name: `${otherValue} pt`, value: parseFloat(otherValue) })}>
          <Input type="number" value={otherValue} onChange={(e) => setOtherValue(e.target.value)}
                 onClick={(e) => e.stopPropagation()}
                 onKeyDown={(e) => {
                   if (e.key === 'Enter') {
                     if (e.target.value) {
                       onChange({ name: `${otherValue} pt`, value: parseFloat(e.target.value) })
                     }
                     setDropdownOpen(false)
                   }
                 }}
          />
        </DropdownItem>
      </DropdownMenu>
    </Dropdown>

  )
}
