/**
 * A component that is loaded for displaying a product of type Kit
 *
 * @param {object} customState - the entire object from redux state
 * @param {object} router - the information about the current route, query param, etc
 *
 */

import { useEffect, useRef, useState } from 'react'
import { useLocation, useNavigate, useSearchParams } from 'react-router-dom'
import KitQuantity from './KitQuantity'
import KitItemsList from './KitItemsList'
import { isOutOfStock } from '../Inventory'
import Price from '../Price'
import { LoadingDots, Popover } from '$core-components'
import { PopoverBody } from 'reactstrap'
import themeContext from '$ustoreinternal/services/themeContext'
import urlGenerator from '$ustoreinternal/services/urlGenerator'
import { decodeStringForURL } from '$ustoreinternal/services/utils'
import location from '$ustoreinternal/services/locationProvider'
import { UStoreProvider } from '@ustore/core'
import { t } from '$themelocalization'
import deepcopy from 'deepcopy'
import { kitChangeType } from './consts'
import './KitProduct.scss'
import Preview from "../Preview";
import ProductDetailsKit from './ProductDetailsKit'

const onScroll = () => {
  // make sure needed HTML elements exist
  const footer = document.querySelector('.footer')
  const stickyPanel = document.querySelector('.sticky-price-panel')

  if (!stickyPanel || stickyPanel.length === 0 || !footer) return

  if (footer.getBoundingClientRect().top <= window.innerHeight) {
    stickyPanel.classList.remove('fixed')
  }
  else {
    stickyPanel.classList.add('fixed')
  }
}

const setAllKitViewModel = (items, object) => {
  const kitViewModelToMerge = { kitViewModel: { items: {} } }
  items && Object.keys(items).forEach(key => {
    kitViewModelToMerge.kitViewModel.items[key] = object
  })

  UStoreProvider.state.customState.merge(kitViewModelToMerge)
}

const KitProduct = ({ customState }) => {
  const navigate = useNavigate()
  const { pathname: asPath } = useLocation()
  const [searchParams] = useSearchParams()

  const [doValidate, setDoValidate] = useState(false)
  const [isKitQuantityValid, setIsKitQuantityValid] = useState(true)
  const [isPriceCalculating, setIsPriceCalculating] = useState(true)
  const [showLoadingOnContinue, setShowLoadingOnContinue] = useState(true)
  const [isLoading, setIsLoading] = useState(false)
  const [isLoadingReorder, setIsLoadingReorder] = useState(false)
  const [showWarningPopover, setShowWarningPopover] = useState(false)
  const [showErrorPopover, setShowErrorPopover] = useState(false)

  const initialDataLoaded = useRef(false) // flag to indicate whether the data APIs were already called.
  const firstPriceCalculated = useRef(false)
  const ContinueErrorProperties = useRef(false)
  const ContinueErrorQuantity = useRef(false)
  const quantityChangeTriggered = useRef(false)
  const showItemsErrorOnKit = useRef(false)
  const lastChangedOrderItemID = useRef(0)
  const locked = useRef(false)
  const lastChangeRequestID = useRef(undefined)

  const getData = async (productID, orderItemID) => {
    if (!productID) return

    const product = await UStoreProvider.api.products.getProductByID(productID, true)
    let orderProduct = null

    let currentOrderItemId;
    if (searchParams) {
        currentOrderItemId = searchParams.get('OrderItemId')
    }

    if (orderItemID || currentOrderItemId) {
      orderProduct = await UStoreProvider.api.orders.getOrderItem(orderItemID || currentOrderItemId)
    } else {
      orderProduct = await UStoreProvider.api.orders.addOrderItem(productID)
    }

    const lastOrder = await UStoreProvider.api.orders.getLastOrder(productID)

    const kitViewModel = { items: {} }
    orderProduct.Items.forEach(orderItem => {
      kitViewModel.items[orderItem.ID] = {
        iframeLoading: false,
        iframeLoaded: null,
        propsWasOpened: false,
        modalIsOpen: false,
        showPropsNotOpenedWarning: false,
        isPropertiesValid: null,
        isQuantityValid: null
      }

      if (orderItem.IsIncluded && product.Items) {
        const productItem = product.Items.find(
          kitProductItem => kitProductItem.Product.ID === orderItem.ProductID
        )
        if (productItem && productItem.Product.Inventory && isOutOfStock(productItem.Product.Inventory.Quantity, productItem.Product.Configuration.Quantity.Minimum, productItem.Product.Inventory.AllowOutOfStockPurchase)) {
          orderItem.IsIncluded = false
        }
      }
    })

    UStoreProvider.state.customState.setBulk({ currentProduct: product, currentOrderItem: orderProduct, lastOrder: lastOrder, kitViewModel: kitViewModel })
  }

  // A method to calculate the price of this kit OrderItem.
  // The price is calculated with the API and change the price model in the state in order to re render all children.
  // Optional parameter:
  //    - updatedKitOrderItem - an updated kit OrderItem to perform calculation of price according to, if doesnt exist takes the currentOrderItem from the props
  const onCalculatePrice = async (updatedKitOrderItem, requestID) => {
    const { currentOrderItem } = customState

    setIsPriceCalculating(true)

    const kitOrderItemForPrice = updatedKitOrderItem ? updatedKitOrderItem : currentOrderItem

    const priceModel = await UStoreProvider.api.orders.getPriceOrderItem(kitOrderItemForPrice.ID, kitOrderItemForPrice)

    //validating that the returned price is the one received from the last updated OrderItem object, otherwise discard it.
    if (lastChangeRequestID.current === requestID || !requestID) {
      UStoreProvider.state.customState.set('currentOrderItemPriceModel', priceModel)
      setIsPriceCalculating(false)
    }
  }

  //this function is called when something has changed - kit_quantity/quantity/remove/add/save - price should be recalculate
  const onChange = (orderItemID, changeType, data) => {
    let updatedKitOrderItem
    let orderItem
    let requestID

    //performing a lock in this thread in order to prevent concurrent updates on the OrderItem object
    if (!locked.current) {
      locked.current = true

      const { currentOrderItem } = customState

      updatedKitOrderItem = deepcopy(currentOrderItem)
      const orderItems = updatedKitOrderItem.Items
      switch (changeType) {
        case kitChangeType.KIT_QUANTITY:
          updatedKitOrderItem.Quantity = parseInt(data.quantity)
          break
        case kitChangeType.QUANTITY:
          orderItem = orderItems.find(item => item.ID === orderItemID)
          orderItem.Quantity = parseInt(data.quantity)
          break
        case kitChangeType.REMOVE:
          orderItem = orderItems.find(item => item.ID === orderItemID)
          orderItem.IsIncluded = false
          break
        case kitChangeType.ADD:
          orderItem = orderItems.find(item => item.ID === orderItemID)
          orderItem.IsIncluded = true
          //TODO: set showLoadingOnContinue: true only if item has properties
          setShowLoadingOnContinue(true)
          break
        case kitChangeType.SAVE:
          break
        default:
        // do nothing t
      }

      //saving the last OrderItemID that made the request in order to know which loader to show
      lastChangedOrderItemID.current = orderItemID

      //saving the last requestID in order to know when the last updated price is returned and show it
      requestID = Math.floor(Math.random() * Math.pow(10, 17)) + 1
      lastChangeRequestID.current = requestID

      UStoreProvider.state.customState.set('currentOrderItem', updatedKitOrderItem)
      locked.current = false
    }

    updatedKitOrderItem && onCalculatePrice(updatedKitOrderItem, requestID)
      .then((res) => res)
      .catch((err) => err)
  }

  const routeToCustomization = async () => {
    const { currentOrderItem } = customState

    const updatedFromDB = await UStoreProvider.api.orders.updateOrderItem(currentOrderItem.ID, currentOrderItem)

    //route only if update succeeded
    if (updatedFromDB) {
      if (!asPath.toLowerCase().includes(('?OrderItemID=').toLowerCase())) {
        const href = `${asPath}?OrderItemID=${currentOrderItem.ID}`

        let currentState = window.history.state
        // in Safari, history.state is NULL, so we need to replace it with an object.
        if (currentState === null || currentState === undefined) {
          currentState = { url: '', as: '', options: {} }
        }

        currentState.url = href
        currentState.as = href

        window.history.replaceState(currentState, '', href)
      }

      // now move to the next page (customization)
      navigate(urlGenerator.get({ page: 'customization' }) + `?OrderItemID=${currentOrderItem.ID}`)
    }
  }

  const onClickContinue = () => {
    if (showLoadingOnContinue || isLoading) return

    const { currentOrderItem, kitViewModel: { items } } = customState

    const hasIncluded = currentOrderItem.Items && currentOrderItem.Items.find(item => item.IsIncluded) !== undefined

    if (!hasIncluded) return

    setAllKitViewModel(items, { isPropertiesValid: null })
    setDoValidate(true)
    setIsLoading(true)
    setIsLoadingReorder(false)
  }

  const onClickContinueAnyway = () => {
    routeToCustomization()
      .then((res) => res)
      .catch((err) => err)
  }

  const onQuantityChange = (value, isvalid) => {
    const { currentOrderItem } = customState

    if (currentOrderItem.Quantity !== value) {
      quantityChangeTriggered.current = true
      onChange(null, kitChangeType.KIT_QUANTITY, { quantity: value })
    }

    setIsKitQuantityValid(isvalid)
  }

  const toggleWarningPopover = () => {
    setShowWarningPopover(false)
    const notEdited = document.getElementsByClassName('not-edited')
    notEdited && notEdited.length && notEdited[0].scrollIntoView(true)
  }

  const toggleErrorPopover = () => {
    setShowErrorPopover(false)
  }

  const onReorder = async () => {
    const { currentProduct, lastOrder } = customState
    setIsLoading(true)
    setIsLoadingReorder(true)
    const newOrder = await UStoreProvider.api.orders.reorder(lastOrder.OrderItemID)
    const newURL = `${urlGenerator.get({ page: 'products', id: currentProduct.FriendlyID, name: decodeStringForURL(currentProduct.Name) })}?OrderItemId=${newOrder.ID}&reorder=true`
    location.replace(newURL)
  }

  useEffect(() => {
    window.addEventListener('scroll', onScroll, true)

    onScroll()

    return () => {
      window.removeEventListener('scroll', onScroll, true)
      UStoreProvider.state.customState.delete('currentProduct')
      UStoreProvider.state.customState.delete('currentOrderItem')
      UStoreProvider.state.customState.delete('currentOrderItemId')
      UStoreProvider.state.customState.delete('currentOrderItemPriceModel')
      UStoreProvider.state.customState.delete('kitViewModel')
      UStoreProvider.state.customState.delete('lastOrder')
    }
  }, [])

  // mirrors the old componentDidUpdate — runs after every render; the guard skips until all data is in
  useEffect(() => {
    if (!customState) return

    const { currentProduct, currentOrderItem, kitViewModel } = customState

    if (!currentOrderItem || !kitViewModel || !currentProduct || !currentProduct.Items) return // we still don't have all data, do not continue.

    const { items } = kitViewModel

    // if this is the first time we are getting the current order Item, and we found items with iframes, start showing loader on continue button, and calculate p
    if (!firstPriceCalculated.current) {
      firstPriceCalculated.current = true

      const itemsWithNoProperties = currentOrderItem.Items.filter(orderItem => {
        const productItem = orderItem && currentProduct.Items.find(kitProductItem => orderItem.ProductID === kitProductItem.Product.ID).Product
        return (productItem && !productItem.Configuration.Properties.length)
      }).map(item => item.ID)

      //check if there are items which are included and have properties
      const includedItemsWithIframe = currentOrderItem.Items.filter(orderItem => {
        return orderItem.IsIncluded && !itemsWithNoProperties.includes(orderItem.ID)
      })

      setShowLoadingOnContinue(!!includedItemsWithIframe.length)

      onCalculatePrice()
        .then((res) => res)
        .catch((err) => err)
      return
    }

    const includedItems = currentOrderItem.Items.filter(item => item.IsIncluded).map(item => item.ID)

    const itemsWithNoProperties = currentOrderItem.Items.filter(orderItem => {
      const productItem = orderItem && currentProduct.Items.find(kitProductItem => orderItem.ProductID === kitProductItem.Product.ID).Product
      return (productItem && !productItem.Configuration.Properties.length)
    }).map(item => item.ID)

    //check if all included kit items with properties has finished loading their iframes
    const allIncludedIframesAreLoaded = Object.keys(items).every(key => {
      return !includedItems.includes(key) ||
        (items[key].iframeLoaded && includedItems.includes(key)) ||
        itemsWithNoProperties.includes(key)
    })

    //if all included kit items are loaded - remove loading from continue
    if (showLoadingOnContinue && allIncludedIframesAreLoaded) {
      setShowLoadingOnContinue(false)
    }

    //if the kit quantity was changed and there is at least one item with invalid quantity - show general error on kit quantity
    if (quantityChangeTriggered.current && Object.keys(items).find(key => includedItems.includes(key) && items[key].isQuantityValid === false)) {
      showItemsErrorOnKit.current = true
    }

    //if the show general error on kit quantity is shown and all items have valid quantity or are not included - remove general error, remove flag of quantity changed
    if (showItemsErrorOnKit.current && Object.keys(items).every(key => !includedItems.includes(key) || items[key].isQuantityValid)) {
      showItemsErrorOnKit.current = false
      quantityChangeTriggered.current = false
    }

    const allItemsValidationReturned = Object.keys(items).every(key => !includedItems.includes(key) || items[key].isPropertiesValid !== null)

    //if all items returned from validation with any isValid value:
    //  - remove loader on right side
    //  - if at least one item is invalid or kit quantity is invalid - do nothing (errors are already shown)
    //  - if all items are valid and kit quantity is valid check for warning on continue for not opening all items' props window
    //  - if all items' props were opened dont show warning, navigate to next page
    if (isLoading && allItemsValidationReturned) {

      setIsLoading(false)
      setIsLoadingReorder(false)
      setDoValidate(false)

      //all is valid if kit quantity is valid, and all items have valid properties and valid quantity (or they are initially not included and their quantity in null)
      const isAllValid = isKitQuantityValid &&
        Object.keys(items).every(key => !includedItems.includes(key) || (items[key].isPropertiesValid && items[key].isQuantityValid)
        )

      if (isAllValid) {
        //reset flag for showing validation error popover
        ContinueErrorQuantity.current = false

        const allOpened = Object.keys(items).every(key => {
          return !includedItems.includes(key) ||
            items[key].propsWasOpened ||
            itemsWithNoProperties.includes(key)
        })

        // if at least one is included, has properties and not opened -> show the continue popover
        if (!allOpened) {
          setShowWarningPopover(!showWarningPopover)
          setAllKitViewModel(items, { showPropsNotOpenedWarning: true })
          return
        }

        // if valid and no need for popover, first put the OrderItemID into the URL, for navigation.
        routeToCustomization()
          .then((res) => res)
          .catch((err) => err)
      }
      else {
        setShowErrorPopover(true)
        //if kit quantity is not valid or there is at least one item with invalid quantity - raise flag for quantity error
        ContinueErrorQuantity.current = !isKitQuantityValid || Object.keys(items).find(key => includedItems.includes(key) && items[key].isQuantityValid === false)
        //if there is at least one item with invalid properties - raise flag for properties error
        ContinueErrorProperties.current = Object.keys(items).find(key => includedItems.includes(key) && items[key].isPropertiesValid === false)

        const nonValidItems = document.getElementsByClassName('not-valid')
        nonValidItems && nonValidItems.length && nonValidItems[0].scrollIntoView(false)
      }
    }

    //if any of the items has a modal opened, prevent scrolling on the back
    if (Object.keys(items).find(key => items[key].modalIsOpen)) {
      document.querySelector('html').classList.add('modal-open')
    }
    else {
      document.querySelector('html').classList.remove('modal-open')
    }
  })

  if (!customState) return null

  const { currentProduct, currentOrderItem, lastOrder, kitViewModel, currentOrderItemPriceModel, currentOrderItemId } = customState

  if (!initialDataLoaded.current && currentProduct) {
    initialDataLoaded.current = true

    getData(currentProduct.ID, currentOrderItemId)
      .then((res) =>res)
      .catch((err) => err)

    return null
  }

  const showReorderLink = !!searchParams.get('reorder')

  const { languageCode } = themeContext.get()

  if (!currentProduct) return null

  const quantityError = showItemsErrorOnKit.current ? t('KitProduct.Validation_kit_quantity_change_invalid_items') : null

  const catalogNumber = currentProduct.CatalogNumber ? ' / ' + currentProduct.CatalogNumber : ''

  const hasIncluded = !currentOrderItem || !currentOrderItem.Items ? null : currentOrderItem.Items.find(item => item.IsIncluded) !== undefined
  const showQuantity = !currentOrderItem ? false : !(!currentProduct.Configuration.Quantity.Changeable && currentOrderItem.Quantity === 1)

  return (
    <div className='kit-product'>
      <div className='main'>
        <div  className="root-preview" role="region" aria-label={t('product.preview')}>
          <Preview product={currentProduct} isKitProduct={true} productThumbnails={currentProduct}/>
        </div>
        <div className='fixed-size-right'>
          {isLoading && (
            <div className='right-side-loading-container'>
              <div className='loading-content-container'>
                {isLoadingReorder && <div className='reorder-loading-msg'>{t('KitProduct.Reorder_loading_msg')}</div>}
                <LoadingDots />
              </div>
            </div>
          )}
          <ProductDetailsKit
            currentProduct={currentProduct}
            catalogNumber={catalogNumber}
            lastOrder={lastOrder}
            showReorderLink={showReorderLink}
            languageCode={languageCode}
            onReorder={onReorder}
          />
          {showQuantity && currentOrderItem && <span className='kit-quantity'>
            {t('KitProduct.Quantity')}
            <div className='quantity-wrapper'>
              <KitQuantity
                onQuantityChange={onQuantityChange}
                productModel={currentProduct}
                orderModel={currentOrderItem}
              />
              {quantityError && (
                <div className='quantity-error'>{quantityError}</div>
              )}
            </div>
          </span>}

          <div className='divider' />
          <span className='kit-includes-title'>{t('KitProduct.Kit_includes')}</span>
          <div className='kit-item-list-wrapper'>
            {currentOrderItem && kitViewModel && currentOrderItemPriceModel ?
              <KitItemsList
                kitOrderItem={currentOrderItem}
                kitProduct={currentProduct}
                kitViewModel={kitViewModel}
                kitOrderItemPriceModel={currentOrderItemPriceModel}
                doValidate={doValidate}
                onCalculatePrice={onCalculatePrice}
                onChange={onChange}
                isPriceCalculating={isPriceCalculating}
                lastChangedOrderItemID={lastChangedOrderItemID.current}
                kitQuantity={currentOrderItem.Quantity}
              />
              :
              <div className='list-loader'>
                <LoadingDots />
              </div>
            }
          </div>

          <div id='kit-product-popover-container' />

          <div className='sticky-price-panel fixed'>
            <span className='total-price'>
              {isPriceCalculating && <LoadingDots />}
              {!isPriceCalculating && currentOrderItemPriceModel && <Price model={currentOrderItemPriceModel.Total.Price} isMinimumPrice={currentOrderItemPriceModel.Total.IsMinimumPrice} />}
            </span>

            <div
              id='kit-continue-button'
              className='continue-button button button-primary truncate'
              role="button"
              tabIndex={!hasIncluded || isLoading ? -1 : 0}
              onClick={onClickContinue}
              onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onClickContinue() } }}
              aria-disabled={!hasIncluded || isLoading}
            >
              {showLoadingOnContinue ?
                <LoadingDots />
                :
                t('KitProduct.Continue')}
            </div>

            {
              showWarningPopover &&
              <Popover
                className='continue-popover warning'
                container='kit-product-popover-container'
                isOpen={showWarningPopover}
                placement='top'
                target='kit-continue-button'
                toggle={toggleWarningPopover}>
                <PopoverBody>
                  <div className='continue-popover-message'>
                    {t('KitProduct.Continue_warning_msg')}
                  </div>
                  <div className='popover-buttons'>
                    <div
                      className='button btn-popover-cancel'
                      onClick={toggleWarningPopover} >
                      {t('KitProduct.Continue_warning_cancel')}
                    </div>
                    <div
                      className='btn-popover-continue button button-secondary'
                      onClick={onClickContinueAnyway} >
                      {t('KitProduct.Continue_warning_continue')}
                    </div>
                  </div>
                </PopoverBody>
              </Popover>
            }
            {
              showErrorPopover &&
              <Popover
                className='continue-popover error'
                container='kit-product-popover-container'
                isOpen={showErrorPopover}
                placement='top'
                target='kit-continue-button'
                toggle={toggleErrorPopover}>
                <PopoverBody>
                  <div className='popover-close'><div className='close-btn' onClick={toggleErrorPopover}>×</div></div>
                  <div className='continue-popover-message'>
                    {t('KitProduct.Continue_error_msg')}&nbsp;
                    {
                      ContinueErrorProperties.current && ContinueErrorQuantity.current ?
                        <div>
                          <ul>
                            <li>{t('KitProduct.Continue_error_edit_msg')}</li>
                            <li>{t('KitProduct.Continue_error_quantity_msg')}</li>
                          </ul>
                        </div>
                        :
                        ContinueErrorProperties.current ? t('KitProduct.Continue_error_edit_msg') : t('KitProduct.Continue_error_quantity_msg')
                    }
                  </div>
                </PopoverBody>
              </Popover>
            }
          </div>
        </div>
      </div>
    </div>
  )
}

export default KitProduct
