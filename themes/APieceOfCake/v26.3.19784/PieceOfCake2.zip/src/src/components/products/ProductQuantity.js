/**
 * A component to display quantity input based on quantity data model
 *
 * @param {function} onQuantityChange(value, isValid) - a callback fired when quantity was changed.
 * @param {object} productModel
 * @param {object} orderModel
 * @param {supportsInventory} boolean
 */

import { useEffect, useState } from 'react'
import './ProductQuantity.scss'
import BaseQuantity from './/BaseQuantity'
import { t } from '$themelocalization'

const ProductQuantity = ({ productModel, orderModel, onQuantityChange, supportsInventory, recipientCount }) => {
  const [errorMessage, setErrorMessage] = useState('')

  const getValidationErrorMessage = (value) => {
    const { Configuration: { Quantity: { Minimum, Maximum } }, Inventory } = productModel

    const inventory = supportsInventory && Inventory ? Inventory.Quantity : null

    if (isNaN(value) || (typeof value === 'string' && value === '')) {
      return <span className='validation-required'>{t('KitQuantity.Validation_required')}</span>
    }

    // Recipient-list products validate the whole-order total (recipients x per-recipient quantity);
    // with no uploaded list the order counts as a single recipient.
    const effectiveQuantity = recipientCount > 0 ? Number(value) * recipientCount : Number(value)

    if (Minimum && effectiveQuantity < Minimum) {
      return <span className='validation-minimum'>{t('KitQuantity.Validation_minimum', { MinimumQuantity: Minimum })}</span>
    }

    if (Maximum && effectiveQuantity > Maximum) {
      return <span className='validation-maximum'>{t('KitQuantity.Validation_maximum', { MaximumQuantity: Maximum })}</span>
    }

    if (inventory && Number(value) > inventory && !Inventory.AllowOutOfStockPurchase) {
      return <span className='validation-inventory'>{t('KitQuantity.Validation_inventory', { InventoryQuantity: inventory })}</span>
    }

    return null
  }

  const onChange = (e, initialChange = false) => {
    const value = e.target.value
    const message = getValidationErrorMessage(value)

    setErrorMessage(message)

    // send new value and error (if any, null if valid) to parent.
    onQuantityChange(value, message, initialChange)
  }

  useEffect(() => {
    const { Configuration: { Quantity } } = productModel
    // validate on mount (to show errors on the default value) and when the recipient count changes
    // (e.g. a list is uploaded), so a min/max error shown for a single recipient clears once the
    // order total meets the requirement.
    if ((Quantity.Changeable && Quantity.Options === null)) {
      // text box
      onChange({ target: { value: orderModel.Quantity || Quantity.Minimum } }, true)
    }
  }, [recipientCount])

  const { Configuration: { Quantity }, ID, Unit } = productModel

  // if no Configuration or if value = 1 and read only => dont show anything
  if (!Quantity || !orderModel.Quantity) {
    return null
  }
  const additionalClassName = errorMessage ? 'not-valid' : ''

  const isPlural = orderModel.Quantity > 1
  const itemUnitName = Unit.PackType
    ? (isPlural ? Unit.PackType.PluralName : Unit.PackType.Name)
    : Unit.ItemType ? (isPlural ? Unit.ItemType.PluralName : Unit.ItemType.Name) : ''

  const packDesc = Unit.PackType ? ` (${t('product.packs_notation',
    {
      PackTypeName: Unit.PackType.Name,
      ItemQuantity: Unit.ItemQuantity,
      ItemTypePluralName: Unit.ItemType.PluralName
    })})` : ''

  return (<div className='product-quantity-component'>
    <BaseQuantity
      quantityConfig={Quantity}
      additionalClassName={additionalClassName}
      quantity={orderModel.Quantity}
      id={ID}
      onChange={onChange}
    />
    <span className='quantity-units'>{itemUnitName}</span>
    {Unit.PackType && <span className='pack-description'>{packDesc}</span>}
    {errorMessage && (<span className='quantity-error'>{errorMessage}</span>)}
  </div>)
}

export default ProductQuantity
