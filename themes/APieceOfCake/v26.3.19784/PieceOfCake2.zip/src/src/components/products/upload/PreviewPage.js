import { t } from '$themelocalization'
import { PDFRenderer } from './PDFRenderer'
import { Bleed } from './overlays/Bleed'
import {
  calculateCanvasSize,
  getFirstWrapperClasses,
  getPageStyle,
  getShowBleed,
  getWrapperClasses
} from './previewLayout'

export const PreviewPage = ({
  viewerState,
  rendererState,
  product,
  fileName,
  orderItem,
  stickyPreview,
  isMobilePreview = false,
  overlays,
  side = 'left',
  useFirstWrapperClasses = true,
  coverClass = '',
  overlayIsBack = false,
  allowBleed = true,
  skipThumbnail = false,
  disableCoverPages = false,
  zoomable = false,
  onZoomClick,
  documentLoaded,
  setViewerState,
  onPdfLoaded,
  setIsDocumentLoading,
}) => {
  const showBleed = getShowBleed(viewerState, product, stickyPreview, isMobilePreview)
  const isNoFittingMode = viewerState.FitMode === 'None'
  const canvasSize = isNoFittingMode ? calculateCanvasSize(viewerState, product) : null
  const wrapperClasses = useFirstWrapperClasses ? getFirstWrapperClasses(viewerState) : getWrapperClasses(viewerState)
  const zoomProps = zoomable ? {
    role: 'button',
    tabIndex: 0,
    onClick: onZoomClick,
    onKeyDown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onZoomClick && onZoomClick(e) } },
    'aria-label': t('GallerySelectorDuc.AiZoomImage')
  } : {}

  return (
    <div className={`${wrapperClasses} ${coverClass} ${zoomable ? 'zoomable' : ''}`} style={getPageStyle(viewerState, product, showBleed)} {...zoomProps}>
      <PDFRenderer name={fileName}
                   stickyPreview={stickyPreview}
                   skipThumbnail={skipThumbnail}
                   disableCoverPages={disableCoverPages}
                   orderItemID={orderItem.ID}
                   state={rendererState || viewerState}
                   setState={setViewerState}
                   onPdfLoaded={onPdfLoaded}
                   documentLoaded={documentLoaded}
                   setIsDocumentLoading={setIsDocumentLoading}
                   side={side}
                   canvasSize={canvasSize}
      />
      {overlays && overlays.map((overlay, i) => overlay(i, overlayIsBack, side, viewerState))}
      {showBleed && allowBleed && <Bleed viewerState={viewerState} canvasSize={canvasSize} product={product}/>}
    </div>
  )
}