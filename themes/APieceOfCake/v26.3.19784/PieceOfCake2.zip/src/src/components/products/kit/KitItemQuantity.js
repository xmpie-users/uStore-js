/**
 * A component to display quantity input based on quantity data model
 *
 * @param {function} onQuantityChange(value, isValid) - a callback fired when quantity was changed.
 * @param {number} kitQuantity - the number of Kits (to multiply in case of Component Quantity)
 * @param {object} productModel
 * @param {object} orderModel
 */

import { useEffect, useRef, useState } from 'react'
import './KitQuantity.scss'
import { Tooltip } from 'reactstrap'
import BaseQuantity from '../BaseQuantity'
import { t } from '$themelocalization'

const KitItemQuantity = ({ productModel, orderModel, onQuantityChange, kitQuantity }) => {
  const [errorMessage, setErrorMessage] = useState('')

  const getValidationErrorMessage = (value) => {
    const { Unit, Configuration: { Quantity: { Minimum, Maximum } }, Inventory } = productModel

    const itemUnitName = Unit.PackType ? Unit.PackType.PluralName : Unit.ItemType ? Unit.ItemType.PluralName : ''

    const inventory = Inventory ? Inventory.Quantity : null

    if (!value || isNaN(value)) {
      return t('KitQuantity.Validation_required')
    }

    if (Minimum && Number(value) < Minimum) {
      return t('KitQuantity.Validation_minimum', { MinimumQuantity: Minimum })
    }

    if (Maximum && Number(value) * kitQuantity > Maximum) {
      return kitQuantity === 1
        ? t('KitQuantity.Validation_maximum', { MaximumQuantity: Maximum })
        : `${t('KitQuantity.Validation_maximum', { MaximumQuantity: Maximum })}.
                    ${t('KitQuantity.Validation_quantity_multiplier', {
    Quantity: Number(value),
    UnitPluralName: itemUnitName,
    KitQuantity: kitQuantity,
    TotalQuantity: kitQuantity * Number(value)
  })}
                `
    }

    if (inventory && Number(value) * kitQuantity > inventory && !Inventory.AllowOutOfStockPurchase) {
      return kitQuantity === 1
        ? t('KitQuantity.Validation_inventory', { InventoryQuantity: inventory })
        : `${t('KitQuantity.Validation_inventory', { InventoryQuantity: inventory })}
                ${t('KitQuantity.Validation_quantity_multiplier', {
    Quantity: Number(value),
    UnitPluralName: itemUnitName,
    KitQuantity: kitQuantity,
    TotalQuantity: kitQuantity * Number(value)
  })}`
    }

    return null // valid
  }

  const onChange = (e) => {
    const value = e.target.value
    const message = getValidationErrorMessage(value)

    setErrorMessage(message)

    // send new value and error (if any, null if valid) to parent.
    onQuantityChange(value, message === null)
  }

  useEffect(() => {
    if (!orderModel) {
      return
    }

    // run onChange on mount, to show validation errors on default value.
    onChange({ target: { value: orderModel.Quantity } })
  }, [])

  const isFirstRender = useRef(true)
  useEffect(() => {
    if (isFirstRender.current) {
      isFirstRender.current = false
      return
    }
    if (!isNaN(kitQuantity)) {
      onChange({ target: { value: orderModel.Quantity } })
    }
  }, [kitQuantity])

  if (!productModel || !orderModel) {
    return null
  }

  const { Configuration: { Quantity }, ID } = productModel

  if (!Quantity) {
    return null
  }
  const additionalClassName = errorMessage ? 'not-valid' : ''

  return (<div className='kit-quantity-component'>
    <BaseQuantity
      quantityConfig={Quantity}
      additionalClassName={additionalClassName}
      quantity={orderModel.Quantity}
      id={ID}
      onChange={onChange}
    />
    {errorMessage &&
          <Tooltip className='quantity-error-tooltip' placement="bottom" isOpen={true} target={'quantity_' + ID}>
            {errorMessage}
          </Tooltip>
    }
  </div>)
}

export default KitItemQuantity
