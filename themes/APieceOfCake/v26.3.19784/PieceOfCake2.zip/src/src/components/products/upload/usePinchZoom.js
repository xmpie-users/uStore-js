import { useEffect, useRef, useState } from 'react'

const MAX_SCALE = 4
const MIN_SCALE = 1

const getDistance = (touches) =>
  Math.hypot(touches[0].clientX - touches[1].clientX, touches[0].clientY - touches[1].clientY)

export const usePinchZoom = (enabled) => {
  const targetRef = useRef(null)
  const [transform, setTransform] = useState(null)
  const state = useRef({ scale: 1, panX: 0, panY: 0, startDistance: 0, startScale: 1, lastX: 0, lastY: 0, panning: false })

  useEffect(() => {
    const el = targetRef.current
    if (!enabled || !el) return

    const apply = () => {
      const { scale, panX, panY } = state.current
      setTransform(scale > 1 ? { transform: `translate(${panX}px, ${panY}px) scale(${scale})` } : null)
    }

    const reset = () => {
      state.current.scale = 1
      state.current.panX = 0
      state.current.panY = 0
      setTransform(null)
    }

    const onTouchStart = (e) => {
      if (e.touches.length === 2) {
        state.current.startDistance = getDistance(e.touches)
        state.current.startScale = state.current.scale
        state.current.panning = false
      } else if (e.touches.length === 1 && state.current.scale > 1) {
        state.current.panning = true
        state.current.lastX = e.touches[0].clientX
        state.current.lastY = e.touches[0].clientY
      }
    }

    const onTouchMove = (e) => {
      if (e.touches.length === 2 && state.current.startDistance) {
        e.preventDefault()
        const ratio = getDistance(e.touches) / state.current.startDistance
        state.current.scale = Math.min(MAX_SCALE, Math.max(MIN_SCALE, state.current.startScale * ratio))
        apply()
      } else if (e.touches.length === 1 && state.current.panning) {
        e.preventDefault()
        state.current.panX += e.touches[0].clientX - state.current.lastX
        state.current.panY += e.touches[0].clientY - state.current.lastY
        state.current.lastX = e.touches[0].clientX
        state.current.lastY = e.touches[0].clientY
        apply()
      }
    }

    const onTouchEnd = (e) => {
      if (e.touches.length === 0) {
        state.current.panning = false
        state.current.startDistance = 0
        if (state.current.scale <= 1.02) reset()
      } else if (e.touches.length === 1) {
        state.current.startDistance = 0
      }
    }

    el.addEventListener('touchstart', onTouchStart, { passive: false })
    el.addEventListener('touchmove', onTouchMove, { passive: false })
    el.addEventListener('touchend', onTouchEnd, { passive: false })
    el.addEventListener('touchcancel', onTouchEnd, { passive: false })
    return () => {
      el.removeEventListener('touchstart', onTouchStart)
      el.removeEventListener('touchmove', onTouchMove)
      el.removeEventListener('touchend', onTouchEnd)
      el.removeEventListener('touchcancel', onTouchEnd)
    }
  }, [enabled])

  return { targetRef, transform }
}
