/**
 * A component to display an item of a product of type Kit.
 *
 * @param {object} kitItemProductModel - the product related to this kit item
 * @param {object} kitItemOrderItemModel - the order item related to this kit item
 * @param {object} kitItemViewModel - the view model of this kit item, with all the information about displaying itself
 * @param {object} [kitItemPriceModel] - the order item price model for this kit item order item
 * @param {function} [onChange] - a callback to signal the item has changed
 * @param {boolean} [doLoadIframe] - a flag to denotes a required action of loading the iframe
 * @param {boolean} [doValidate] - a flag to denotes a required action of validation
 * @param {boolean} [isPriceCalculating] - a flag to indicate if the item's price is in loading state
 * @param {number} kitQuantity - the quantity of the parent kit component, used for inventory validations.
 */

import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import sanitizeHTML from 'sanitize-html'
import { useNavigate } from 'react-router-dom'
import KitItemQuantity from './KitItemQuantity'
import Inventory, { isOutOfStock } from '../Inventory'
import Price from '../Price'
import { Tooltip, ImageLoader, LoadingDots, Icon} from '$core-components'
import ImageCarousel from '../ImageCarousel';
import { CookiesManager, storefrontCookies } from '$ustoreinternal/services/cookies'
import logger from '$ustoreinternal/services/logger'
import themeContext from '$ustoreinternal/services/themeContext'
import location from '$ustoreinternal/services/locationProvider'
import { UStoreProvider } from '@ustore/core'
import { t } from '$themelocalization'
import theme from '$styles/theme'
import { Modal, ModalBody, ModalFooter, ModalHeader } from 'reactstrap'
import { Scrollbars } from 'react-custom-scrollbars-2'
import { kitChangeType } from './consts'
import './KitItem.scss'

const setKitViewModel = (orderItemID, object) => {
  UStoreProvider.state.customState.merge({ kitViewModel: { items: { [orderItemID]: object } } })
}

const getIframeSrc = (orderItemID) => {
  const { storeID } = themeContext.get()
  const { currentUser } = UStoreProvider.state.get()

  const desktopBreakpoint = parseInt(theme.lg.replace('px', ''))
  const viewMobileVal = document.body.clientWidth > desktopBreakpoint ? 'viewMobile=false' : 'viewMobile=true'
  const { classicUrl , securityToken} = themeContext.get()
  return `${classicUrl}/ProductProperties.aspx?OrderItemId=${orderItemID}&${viewMobileVal}&isFrameMode=true&rand=${Math.random()}&userUniqueId=${currentUser ? currentUser.ID : ''}&parentUrl=${encodeURIComponent(location.href)}&StoreGuid=${storeID ? storeID : ''}&securityToken=${securityToken}`
}

const KitItem = ({ kitItemProductModel, kitItemOrderItemModel, kitItemPriceModel, doLoadIframe, isPriceCalculating, kitItemViewModel, kitQuantity, onChange, doValidate }) => {
  const navigate = useNavigate()

  const [isPropertiesOpen, setIsPropertiesOpen] = useState(false)
  const [isPreviewOpen, setIsPreviewOpen] = useState(false)
  const [activeModalImage] = useState(0)
  const [isPropsModalLoading, setIsPropsModalLoading] = useState(false)
  const [isMediumBreak, setIsMediumBreak] = useState(false)
  // computed once: getIframeSrc embeds Math.random(), so it must not change between renders
  const [iframeSrc] = useState(() => kitItemOrderItemModel ? getIframeSrc(kitItemOrderItemModel.ID) : '')

  const externalValidation = useRef(false)
  const shouldValidateModal = useRef(false)
  const iframeElementModal = useRef(null)
  const iframeElement = useRef(null)
  const scrollbars = useRef(null)
  const scrollableContainer = useRef(null)

  const validate = () => {
    if (!externalValidation.current && iframeElement.current && iframeElement.current.contentWindow) {
      iframeElementModal.current.contentWindow.postMessage({
        type: '@PRODUCT_PROPERTIES_SAVE',
        data: {}
      }, '*')
    }
    else if (externalValidation.current && iframeElement.current && iframeElement.current.contentWindow) {
      iframeElement.current.contentWindow.postMessage({
        type: '@PRODUCT_PROPERTIES_SAVE',
        data: {}
      }, '*')
    }
  }

  const onValidateIframeReturn = (isPropertiesValid) => {
    const { ID } = kitItemOrderItemModel
    const { modalIsOpen: currentModalIsOpen } = kitItemViewModel
    let modalIsOpen = currentModalIsOpen  //modalIsOpen is set according to current state in kitItemViewModel

    if (!externalValidation.current && isPropertiesValid) {
      iframeElement.current && iframeElement.current.contentWindow && iframeElement.current.contentWindow.location.replace(getIframeSrc(ID))
      setIsPropertiesOpen(false)
      modalIsOpen = false     //if not external validation and properties are valid - modalIsOpen = false
      onChange(ID, kitChangeType.SAVE)
    }
    else if (!externalValidation.current) {
      scrollbars.current && scrollbars.current.scrollToTop()
    }

    if (externalValidation.current) {
      externalValidation.current = false
    }

    setKitViewModel(ID, { isPropertiesValid: !!isPropertiesValid, modalIsOpen: modalIsOpen })
  }

  const onMessageRecieved = (e) => {
    logger.info(e.data.type + ' message from iframe', e)

    if (e.data.type === '@SCROLL_PARENT_DISABLE') {

      var x = document.querySelector('.view').scrollLeft;
      var y = document.querySelector('.view').scrollTop;
      document.querySelector('.view').onscroll = function () { document.querySelector('.view').scrollTo(x, y); };
    }
    if (e.data.type === '@SCROLL_PARENT_ENABLE') {
      document.querySelector('.view').onscroll = function () { }
    }
    if (e.data.type === '@SCROLL_TO' && e.data.data) {
      document.querySelector('.view').scrollTo(e.data.data.x, e.data.data.y);
    }

    if (e.data.type === '@PRODUCT_PROPERTIES_STATUS') {
      const orderItemID = e.data.data.orderItemID
      const isValid = e.data.data.isValid
      if (orderItemID && orderItemID === kitItemOrderItemModel.ID) {
        onValidateIframeReturn(isValid)
      }
    }
    if (e.data.type === '@PRODUCT_POPERTIES_LOADED') {
      const orderItemID = e.data.data.orderItemID
      if (orderItemID && orderItemID === kitItemOrderItemModel.ID) {
        if (kitItemViewModel.iframeLoading) {
          setKitViewModel(kitItemOrderItemModel.ID, { iframeLoading: false, iframeLoaded: true })
        }
        else if (isPropsModalLoading) {
          setIsPropsModalLoading(false)
          if (shouldValidateModal.current) {
            shouldValidateModal.current = false
            externalValidation.current = false
            validate()
          }
        }
      }
    }
    if (e.data.type === '@CHANGE_DIMENSIONS') {
      const orderItemID = e.data.data.orderItemID
      if (orderItemID && orderItemID === kitItemOrderItemModel.ID) {
        const height = e.data.data.height
        const width = e.data.data.width

        if (iframeElementModal.current && iframeElementModal.current.style) {
          iframeElementModal.current.style.height = `${height}px`
          iframeElementModal.current.style.width = `${width}px`

          const modalBody = document.querySelector('.kit-item-properties-modal .modal-body')
          scrollableContainer.current.style.height = `${modalBody.clientHeight - 16}px`
          scrollableContainer.current.style.width = `${modalBody.clientWidth}px`
          scrollbars.current.scrollTop(0)
        }
      }
    }

    if (e.data.type === '@CHANGE_LEGACY_ROUTE') {
      //session expired - we need to prevent displaying login page within iframe
      if (e.data.data.match(/\/login\.aspx\?/) || e.data.data.match(/\/ShowMessage\.aspx\?.*StoreID=-1&ErrorCode=3/)) {
        const { securityToken, storeID, classicUrl, languageCode } = themeContext.get()
        const cookiesToDelete = [storefrontCookies.token, storefrontCookies.storeID, storefrontCookies.language]
        cookiesToDelete.forEach(cn => CookiesManager.deleteCookie(cn))

        const url = `${classicUrl}/logout.aspx?SecurityToken=${securityToken}&StoreGuid=${storeID}&ShowRibbon=false&forceLogin=true&NgLanguageCode=${languageCode}`
        navigate(url)
      }
    }
  }

  useEffect(() => {
    if (!kitItemOrderItemModel) {
      return
    }

    const isMedium = () => document.body.clientWidth <= parseInt(theme.lg.replace('px', ''))
    const mediumBreak = isMedium()

    setIsMediumBreak(mediumBreak)

    if (mediumBreak) {
      const input = document.getElementsByClassName('.quantity-control.quantity-input')
      if (input && input.length === 1) input[0].addEventListener('focus', function (e) { e.target.scrollIntoView(true) })
    }

    const onResizeHandler = () => setIsMediumBreak(isMedium())
    window.addEventListener('resize', onResizeHandler)
    return () => window.removeEventListener('resize', onResizeHandler)
  }, [kitItemOrderItemModel])

  // the message handler reads current props/state — re-subscribe every render to avoid stale closures
  useEffect(() => {
    if (!kitItemOrderItemModel) {
      return
    }

    window.addEventListener('message', onMessageRecieved)
    return () => window.removeEventListener('message', onMessageRecieved)
  })

  // if unmounting (clicking back on the browser) when modal is open, we need to manually remove the modal class from the html tag.
  const modalOpenRef = useRef(false)
  modalOpenRef.current = isPreviewOpen || isPropertiesOpen
  useEffect(() => () => {
    if (modalOpenRef.current && document && document.querySelector('html')) {
      document.querySelector('html').classList.remove('modal-open')
    }
  }, [])

  const prevDoValidate = useRef(doValidate)
  useEffect(() => {
    const wasValidate = prevDoValidate.current
    prevDoValidate.current = doValidate
    if (!doValidate || wasValidate) {
      return
    }

    const { ID, IsIncluded } = kitItemOrderItemModel
    const { isPropertiesValid } = kitItemViewModel
    const hasProperties = !!kitItemProductModel.Configuration.Properties.length

    if (!isPropertiesValid && IsIncluded && hasProperties) {
      externalValidation.current = true
      validate()
    }
    else if (IsIncluded) {
      setKitViewModel(ID, { isPropertiesValid: true })
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [doValidate])

  // moved out of render: mark the hidden iframe as loading once it is about to mount.
  // layout effect, not passive: the flag must be set before the iframe can post @PRODUCT_POPERTIES_LOADED,
  // otherwise that handler matches neither branch and the item stays "loading" forever
  useLayoutEffect(() => {
    if (!kitItemProductModel || !kitItemOrderItemModel || !kitItemViewModel) {
      return
    }
    const hasProperties = !!kitItemProductModel.Configuration.Properties.length
    if (doLoadIframe && kitItemOrderItemModel.IsIncluded && hasProperties && !kitItemViewModel.iframeLoading && !kitItemViewModel.iframeLoaded) {
      setKitViewModel(kitItemOrderItemModel.ID, { iframeLoading: true })
    }
  })

  const onClickCancel = () => {
    const { ID } = kitItemOrderItemModel
    setIsPropertiesOpen(false)   //close even if not valid
    setKitViewModel(ID, { isPropertiesValid: null, modalIsOpen: false })
  }

  const onClickSave = () => {
    externalValidation.current = false
    validate()
  }

  const onClickEditOptions = () => {
    const { ID } = kitItemOrderItemModel

    if (kitItemViewModel.isPropertiesValid === false) {
      shouldValidateModal.current = true
    }

    setIsPropertiesOpen(!isPropertiesOpen)
    setIsPropsModalLoading(true)

    if (!kitItemViewModel.propsWasOpened) {
      setKitViewModel(ID, { propsWasOpened: true, modalIsOpen: true })
    }
    else {
      setKitViewModel(ID, { modalIsOpen: true })
    }
  }

  const onQuantityChange = (quantity, isValid) => {
    const { ID, Quantity } = kitItemOrderItemModel
    setKitViewModel(ID, { isQuantityValid: isValid })

    if (quantity !== Quantity) {
      onChange(ID, kitChangeType.QUANTITY, { quantity })
    }
  }

  const onRemove = () => {
    const { ID } = kitItemOrderItemModel
    onChange(ID, kitChangeType.REMOVE)
    setKitViewModel(ID, { isQuantityValid: null, isPropertiesValid: null })
  }

  const onAdd = () => {
    const { ID } = kitItemOrderItemModel
    onChange(ID, kitChangeType.ADD)
    setKitViewModel(ID, { iframeLoaded: null, isPropertiesValid: null })
  }

  const togglePreviewModal = () => {
    const { ID } = kitItemOrderItemModel
    setIsPreviewOpen(!isPreviewOpen)
    setKitViewModel(ID, { modalIsOpen: !isPreviewOpen })
  }

  const propertiesModalOnOpened = () => {
    document.querySelector('.kit-item-properties-modal .modal-title').classList.add('truncate')
  }

  const renderEditLink = (className, isOutOfStock) => {
    return (
      <div className={'edit-section ' + className}>
        {kitItemOrderItemModel.IsIncluded && kitItemViewModel.iframeLoading && !isOutOfStock && <LoadingDots />}
        {kitItemViewModel.isPropertiesValid === false && (<span className='edit-options-error-icon'><Icon name="error.svg" width="15px" height="15px" className="error-icon" /></span>)}
        {kitItemOrderItemModel.IsIncluded && !kitItemViewModel.iframeLoading && !isOutOfStock && (<span className={'edit-options'} onClick={onClickEditOptions}><Tooltip placement="top" text={t('KitItem.Edit_options')} maxLine={2} /></span>)}
        {(!kitItemOrderItemModel.IsIncluded || isOutOfStock) && (<span className='disabled-edit-options'><Tooltip placement="top" text={t('KitItem.Edit_options')} maxLine={2} /></span>)}
      </div>
    )
  }

  const renderInventoryLabel = (className) => {
    return (
      <span className={className}>
        {kitItemProductModel.Inventory && kitItemProductModel.Inventory.AllowOutOfStockPurchase && <Inventory model={kitItemProductModel.Inventory} minQuantity={kitItemProductModel.Configuration.Quantity.Minimum} />}
      </span>
    )
  }

  if (!kitItemProductModel || !kitItemOrderItemModel || !kitItemViewModel)
    return null

  const { Name, ImageUrl, Thumbnails } = kitItemProductModel
  const { IsIncluded } = kitItemOrderItemModel

  const hasProperties = !!kitItemProductModel.Configuration.Properties.length

  let itemClasses = 'kit-item-panel'
  if (!IsIncluded) itemClasses += ' excluded'

  let kitItemClasses = 'kit-item'
  if ((kitItemViewModel.isPropertiesValid === false || kitItemViewModel.isQuantityValid === false) && !isPropertiesOpen) {
    kitItemClasses += ' not-valid'
  }
  else {
    if (IsIncluded && !kitItemViewModel.propsWasOpened && kitItemViewModel.showPropsNotOpenedWarning && hasProperties) {
      kitItemClasses += ' not-edited'
    }
  }

  const itemUnitName = kitItemProductModel.Unit.PackType ? kitItemProductModel.Unit.PackType.PluralName : kitItemProductModel.Unit.ItemType ? kitItemProductModel.Unit.ItemType.PluralName : ''
  const OutOfStock = kitItemProductModel.Inventory && isOutOfStock(kitItemProductModel.Inventory.Quantity, kitItemProductModel.Configuration.Quantity.Minimum, kitItemProductModel.Inventory.AllowOutOfStockPurchase)

  const itemName = kitItemProductModel.CatalogNumber ? `${Name} / ${kitItemProductModel.CatalogNumber.toString()}` : Name

  const priceNotZero = kitItemPriceModel && kitItemPriceModel.Price && kitItemPriceModel.Price.Price !== 0
  return (
    <div className={kitItemClasses} data-qaautomationinfo={kitItemProductModel.FriendlyID}>
      <div className={itemClasses}>
        <div className='item-image' onClick={togglePreviewModal}>
          <ImageLoader className="image" src={ImageUrl} />
        </div>
        <div className='item-name-price-quantity'>
          <div className='item-name-and-price'>
            <div className='item-name'>
              <Tooltip placement="top" text={itemName} maxLine={2} />
              {hasProperties && renderEditLink('big-screen-only', OutOfStock)}
              {renderInventoryLabel('big-screen-only')}
            </div>
            <div className='item-price'>
              {isPriceCalculating && kitItemPriceModel && priceNotZero && <LoadingDots />}
              {!isPriceCalculating && kitItemPriceModel && priceNotZero && <Price model={kitItemPriceModel.Price} isMinimumPrice={kitItemPriceModel.IsMinimumPrice} />}
            </div>
            {hasProperties && renderEditLink('medium-screen-only', OutOfStock)}
            {renderInventoryLabel('medium-or-small-screen-only')}
          </div>
          {IsIncluded && (!kitItemProductModel.Inventory || kitItemProductModel.Inventory.AllowOutOfStockPurchase === true || kitItemProductModel.Inventory.Quantity >= kitItemProductModel.Configuration.Quantity.Minimum) && <div className="quantity">
            <KitItemQuantity
              onQuantityChange={onQuantityChange}
              kitQuantity={kitQuantity}
              productModel={kitItemProductModel}
              orderModel={kitItemOrderItemModel}
            />
            {IsIncluded && <span className='quantity-label'>{itemUnitName}</span>}
            {kitItemProductModel.Unit.PackType &&
            <span className='quantity-per-pack'>
                {t('KitItem.Units_of_measure_notation',
                  {
                    PackTypeName: kitItemProductModel.Unit.PackType.Name,
                    ItemQuantity: kitItemProductModel.Unit.ItemQuantity,
                    ItemTypePluralName: kitItemProductModel.Unit.ItemType.PluralName
                  })}
              </span>}
          </div>}

          {!IsIncluded && OutOfStock && <div className="out-of-stock"><Inventory model={kitItemProductModel.Inventory} minQuantity={kitItemProductModel.Configuration.Quantity.Minimum} /></div>}
          {!IsIncluded && !OutOfStock && <div className="add-btn"><div className="btn button button-secondary" role="button" tabIndex={0} onClick={onAdd} onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onAdd() } }}>{t('KitItem.Add')}</div></div>}
          {hasProperties && renderEditLink('small-screen-only', OutOfStock)}

        </div>
        {IsIncluded && <div className="remove-btn" role="button" tabIndex={0} onClick={onRemove} onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onRemove() } }} aria-label={t('KitItem.Remove')}>×</div>}

      </div>
      <Modal isOpen={isPropertiesOpen} modalClassName="kit-item-properties-modal" onOpened={propertiesModalOnOpened}>
        <ModalHeader><div dangerouslySetInnerHTML={{__html: sanitizeHTML(`${t('KitItem.Edit_options')} - ${Name}`)}}/><div className='modal-close'><div className='close-btn' onClick={onClickCancel}>×</div></div></ModalHeader>
        <ModalBody>
          {
            !isMediumBreak &&
            <div className="product-thumbnail"><ImageLoader className="image" src={ImageUrl} /></div>
          }
          <div className="scrollable-container" ref={scrollableContainer}>
            <Scrollbars className="scrollbar" universal renderThumbHorizontal={props => <div {...props} className="thumb-horizontal" />}
                        renderThumbVertical={props => <div {...props} className="thumb-vertical" />} renderView={props => <div {...props} className="view" />} ref={scrollbars}>
              {
                isMediumBreak &&
                <div className="product-thumbnail"><ImageLoader className="image" src={ImageUrl} /></div>
              }
              {
                isPropsModalLoading &&
                <div className="properties-loading-container"><LoadingDots /></div>
              }
              <iframe className={`iframe-modal ${isPropsModalLoading ? 'iframe-hidden' : ''}`} src={iframeSrc} ref={iframeElementModal} frameBorder="0" height="400px" title="Kit Item Modal" width="600px" scrolling="no" />
            </Scrollbars>
          </div>
        </ModalBody>
        <ModalFooter>
          <div className="cancel-btn button button-secondary thin" onClick={onClickCancel}>{t('KitItem.Properties_cancel')}</div>
          <div className="save-btn button button-primary thin" onClick={onClickSave}>{t('KitItem.Properties_save')}</div>
        </ModalFooter>
      </Modal>
      {
        doLoadIframe && IsIncluded && hasProperties &&
        <iframe src={iframeSrc} ref={iframeElement} className="iframe-hidden" title='iframe hidden'/>
      }

      <Modal isOpen={isPreviewOpen} modalClassName="kit-preview-modal" toggle={togglePreviewModal}
             backdropClassName="kit-preview-modal-backdrop"
      >
        <ModalBody>
          <div>
            <div className='modal-close'><div className='close-btn' onClick={togglePreviewModal}>×</div></div>
            <div className='modal-title'>
              <Tooltip placement="top" text={Name} maxLine={1} />
            </div>
            <div className='modal-carousel-wrapper'>
              <ImageCarousel id={`kitItemCarousel_${kitItemOrderItemModel.ID}`}
                             activeSlide={activeModalImage}
                             images={Thumbnails.map((image) => {
                               return {
                                 Url: image
                               }
                             })}
                             zoomAllowed={!isMediumBreak}
              />
            </div>
          </div>
        </ModalBody>
      </Modal>
    </div>
  )
}

export default KitItem
