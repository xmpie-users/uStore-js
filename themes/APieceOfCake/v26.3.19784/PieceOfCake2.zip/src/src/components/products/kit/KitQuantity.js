/**
 * A component to display quantity input based on quantity data model
 *
 * @param {function} onQuantityChange(value, isValid) - a callback fired when quantity was changed.
 * @param {object} productModel
 * @param {object} orderModel
 */

import { useEffect, useState } from 'react'
import BaseQuantity from '../BaseQuantity'
import { t } from '$themelocalization'
import './KitQuantity.scss'

const KitQuantity = ({ productModel, orderModel, onQuantityChange }) => {
  const [errorMessage, setErrorMessage] = useState('')

  const getValidationErrorMessage = (value) => {
    const { Configuration: { Quantity: { Minimum, Maximum } } } = productModel

    if (!value || isNaN(value)) {
      return t('KitQuantity.Validation_required')
    }

    if (Minimum && Number(value) < Minimum) {
      return t('KitQuantity.Validation_minimum', { MinimumQuantity: Minimum })
    }

    if (Maximum && Number(value) > Maximum) {
      return t('KitQuantity.Validation_maximum', { MaximumQuantity: Maximum })
    }

    return null
  }

  const onChange = (e) => {
    const value = e.target.value
    const message = getValidationErrorMessage(value)

    setErrorMessage(message)

    // send new value and error (if any, null if valid) to parent.
    onQuantityChange(value, message === null)
  }

  useEffect(() => {
    const { Configuration: { Quantity } } = productModel
    // run onChange on mount, to show validation errors on default value.
    if ((Quantity.Changeable && Quantity.Options === null)) {
      // text box
      onChange({ target: { value: orderModel.Quantity } })
    }
  }, [])

  const { Configuration: { Quantity }, ID } = productModel

  // if no Configuration or if value = 1 and read only => dont show anything
  if (!Quantity || (!Quantity.Changeable && orderModel.Quantity === 1)) {
    return null
  }
  const additionalClassName = errorMessage ? 'not-valid' : ''

  return (<div className='kit-quantity-component'>
    <BaseQuantity
      quantityConfig={Quantity}
      additionalClassName={additionalClassName}
      quantity={orderModel.Quantity}
      id={ID}
      onChange={onChange}
    />
    {errorMessage && (
      <span className='quantity-error'>{errorMessage}</span>
    )}
  </div>)
}

export default KitQuantity
