import React, { useEffect, useState } from 'react'
import { overlaysAdapter, uploadEasyUploadFile } from './overlays'
import stateAdapter from './stateAdapter'
import { LoadingDots, Slot } from '$core-components'
import DocumentLoader from './DocumentLoader'
import './PDFViewer.scss'
import { UploadDocumentButton } from './UploadDocumentButton'
import { Paginator } from '../Paginatior'
import pdfLoader from './pdfLoader'
import { t } from '$themelocalization'
import { usePDFViewer } from './PDFViewerContext'
import { PreviewPage } from './PreviewPage'
import { EasyUploadPreviewModal } from './EasyUploadPreviewModal'
import { getShowBleed } from './previewLayout'
import { usePinchZoom } from './usePinchZoom'
import { useSwipeable } from 'react-swipeable'
import { getUploadedFileDimensionsText } from './easyUploadUtils'

export const PDFViewer = ({
  resetPopperError,
  setUploadError,
  properties,
  isMobile,
  orderItem,
  product,
  onFormChange,
  stickyPreview,
  isMobilePreview,
  pushPropertiesToServer,
}) => {
  const [documentLoaded, setDocumentLoaded] = useState(false)
  const [overlays, setOverlays] = useState([])
  const [forceInputFile, setForceInputFile] = useState(false)
  const [dropZoneHidden, setDropZoneHidden] = useState(false)
  const [zoomModalOpen, setZoomModalOpen] = useState(false)
  const [zoomInitialPage, setZoomInitialPage] = useState(1)
  const pinch = usePinchZoom(isMobilePreview)

  const {
    fileName,
    setDefault,
    setFileName,
    viewerState,
    setViewerState,
    isDocumentLoading,
    setIsDocumentLoading,
    uploadErrorMessage,
    setUploadErrorMessage,
    preflightWarning,
    setPreflightWarning
  } = usePDFViewer()
  const isEvenPage = viewerState.pageNumber % 2 === 0
  const isOddPage = !isEvenPage
  const isFirstPage = viewerState.pageNumber === 1
  const isDoubleSided = viewerState.doubleSidedPrinting > 1
  const isMultiPageDoubleSided = isDoubleSided && viewerState.totalPageNumber > 2
  const maxPages = viewerState.doubleSidedPrinting > 1 && viewerState.totalPageNumber % 2 !== 0 ? viewerState.totalPageNumber + 1 : viewerState.totalPageNumber
  const swipeDelta = viewerState.doubleSidedPrinting > 1 && viewerState.pageNumber  > 1 && (viewerState.pageNumber <= maxPages) ? 2 : 1

  useEffect(() => {
    if (orderItem.DocumentInfo) {
      const previewUrl = `${product.Proof.Url}&orderitemid=${orderItem.ID}`
      setUploadErrorMessage('')
      setViewerState({
        ...viewerState,
        previewUrl,
        metaData: orderItem.DocumentInfo.MetaData,
        pageNumber: 1,
        totalPageNumber: orderItem.DocumentInfo.MetaData.NumberOfPages,
      })
    } else {
      setUploadError && setUploadError(true)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orderItem.ID, orderItem.DocumentInfo])

  useEffect(() => {
    if (!properties) return
    const getCode = (prop) => prop.custom?.code?.replace(/\s/igm, '')
    const notValidDependants = {};
    const newState = Object.entries(properties)
      .filter(([id, prop]) => !!stateAdapter[getCode(prop)])
      .filter(([id, prop]) => {
        if (prop.depended) {
          const valid = prop.depended?.condition?.enum?.some(depended => properties[prop.depended.parent].value === depended)
          if (!valid) {
            notValidDependants[getCode(prop).toUpperCase()] = true;
          }
          return valid;
        }
        return true
      })
      .map(([id, prop]) => stateAdapter[getCode(prop)](prop, properties))
      .reduce((acc, curr) => ({ ...acc, ...curr }), {})

    const mergedNewState = Object.entries({ ...viewerState, ...newState })
        .filter(([key]) => !notValidDependants[key.toUpperCase()])
        .reduce((acc, curr) => ({ ...acc, [curr[0]]: curr[1] }), {})

    setViewerState(mergedNewState)

    setOverlays(Object.entries(properties)
      .filter(([id, prop]) => !!overlaysAdapter[getCode(prop)])
      .filter(([id, prop]) => {
        if (prop.depended) {
          return prop.depended?.condition?.enum?.some(depended => properties[prop.depended.parent].value === depended)
        }
        return true
      })
      .filter(prop => prop[1]?.propertySchema?.enum)
      // stateOverride: the zoom modal renders these same thunks with its own page position -
      // without it the state baked in here kept the overlays on the page the zoom was opened from.
      .map(([id, prop]) => (k, isBack, side, stateOverride) => overlaysAdapter[getCode(prop)](prop, k, stateOverride ?? mergedNewState, isBack, side, isMobilePreview)))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [properties, viewerState.pageNumber, documentLoaded])

  useEffect(() => {
    if (viewerState.pageNumber > 1 && (viewerState.pageNumber % 2 !== 0 || viewerState.pageNumber > viewerState.totalPageNumber))
    {
        setPage(viewerState.pageNumber - 1)
      }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [viewerState.doubleSidedPrinting])

  useEffect(() => {
    const pdf = pdfLoader.pdf
    if (pdf) {
      setViewerState({
        ...viewerState,
        totalPageNumber: pdf.numPages,
        pageNumber: 1
      })
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ documentLoaded])

  useEffect(() => {
    if (!viewerState.previewUrl && documentLoaded) {
      setDocumentLoaded(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [viewerState.previewUrl])

  const swipeHandlers = useSwipeable({
    onSwipedLeft: () => setPage(Math.min(viewerState.pageNumber + swipeDelta, maxPages)),
    onSwipedRight: () => setPage(Math.max(viewerState.pageNumber - swipeDelta, 1)),
  })

  const handlers = isMobile && documentLoaded ? swipeHandlers : {}

  if (!properties && !stickyPreview) return null

  const onPdfLoaded = (pdf) => {
    resetPopperError && resetPopperError()
    setUploadError && setUploadError(false)
    setDocumentLoaded(true)
    setIsDocumentLoading(false)
    setViewerState({
      ...viewerState,
      totalPageNumber: pdf.numPages,
      pageNumber: 1
    })
  }

  const setPage = (pageNumber) => setViewerState({ ...viewerState, pageNumber })
  const showBleed = getShowBleed(viewerState, product, stickyPreview, isMobilePreview)
  const sideTitle = t(`UploadDocument.${isOddPage ? 'Front' : 'Back'}`)
  const isCover = (pageNumber) => !stickyPreview && isMultiPageDoubleSided && (pageNumber === 1 || pageNumber > viewerState.totalPageNumber + viewerState.totalPageNumber % 2)
  const getCoverClass = (pageNumber) => `${isCover(pageNumber) ? 'cover' : ''}`
  const isZoomable = !stickyPreview && !isMobile && documentLoaded && !isCover(viewerState.pageNumber)
  const openZoomModal = (pageNumber) => {
    setZoomInitialPage(pageNumber)
    setZoomModalOpen(true)
  }

  const renderPageNumber = (pageNumber) => {
    if (!viewerState.doubleSidedPrinting || viewerState.doubleSidedPrinting <= 1 || stickyPreview) return null

    return <div className={`page-number ${isCover(pageNumber) ? 'cover' : ''}`}>
      {t('UploadDocument.PageNumber', { number: isFirstPage && pageNumber === 2 ? 1 : pageNumber })}
    </div>
  }

    const getPageDimension = () => getUploadedFileDimensionsText(product, viewerState)

  return <>
    <div className={`pdf-viewer-container ${stickyPreview ? 'sticky-preview' : ''} ${documentLoaded ? 'loaded' : ''}`}>
      <div className={`preview-wrapper ${viewerState.totalPageNumber === 1 ? 'one-page-document' : ''} ${viewerState.totalPageNumber === 2 ? 'two-page-document' : ''}`}>
        {isMobile && documentLoaded && uploadErrorMessage && <div className="upload-error-block">
          <p className="upload-error" dangerouslySetInnerHTML={{__html: uploadErrorMessage}}/>
        </div>}
        <div {...handlers}
             className={`canvas-container ${viewerState.pageSize} ${isMultiPageDoubleSided ? 'double-side-printing' : ''} ${showBleed ? "bleed" : ""}`}>
          {viewerState.previewUrl && !stickyPreview && !isMobile &&
            <>
              <UploadDocumentButton
                {...{
                  setDocumentLoaded, setFileName, fileName, onFormChange, orderItem, properties, product,
                  setViewerState, viewerState, uploadErrorMessage, setIsDocumentLoading, setUploadErrorMessage,
                  setUploadError, setForceInputFile, onPdfLoaded
                }}
              />
              <Slot name="ng_product_easy_upload_document_replace_button"
                    data={{product, properties, errorMessage: uploadErrorMessage, fileName, orderItem, viewerState}}
                    actions={{
                      onFormChange, setIsDocumentLoading, setUploadError, setViewerState, setForceInputFile,
                      setFileName, setErrorMessage: setUploadErrorMessage, setDocumentLoaded, onPdfLoaded}}
              />
            </>}
          {!viewerState.previewUrl && !dropZoneHidden && <DocumentLoader
                {...{
                  setDocumentLoaded, setFileName, fileName, onFormChange, setIsDocumentLoading, orderItem, properties,
                  viewerState, setViewerState, product, documentLoaded, setUploadError, forceInputFile, onPdfLoaded, setForceInputFile,
                  setPreflightWarning
                }}
                errorMessage={uploadErrorMessage}
                setErrorMessage={setUploadErrorMessage}
              />}
          <Slot name="ng_product_easy_upload_document_below_doc_area"
                data={{
                  product,
                  properties,
                  fileName,
                  orderItem,
                  viewerState,
                  documentLoaded,
                  pdfLoader
                }}
                actions={{
                  onFormChange, setIsDocumentLoading, setUploadError, setViewerState, setForceInputFile,
                  setFileName, setUploadErrorMessage, setDocumentLoaded, onPdfLoaded, uploadEasyUploadFile, setDefault, setDropZoneHidden,
                  pushPropertiesToServer
                }}/>

            {documentLoaded && (
                <div className="preview-warning desktop">
                    {t('UploadDocument.PreviewWarning')}{' '}
                    <span className="no-wrap">{getPageDimension()}</span>
                </div>
            )}
          {documentLoaded && preflightWarning && !uploadErrorMessage && (
                <div className="preflight-warning desktop" dangerouslySetInnerHTML={{__html: preflightWarning}}/>
            )}
          <div className={`pages-wrapper ${isMobilePreview ? 'pinch-zoomable' : ''}`} ref={pinch.targetRef} style={pinch.transform}>
            {viewerState.previewUrl && (
              <div className={isMultiPageDoubleSided ? `double-side-wrapper` : 'single-side-wrapper'}>
                <div className={isMultiPageDoubleSided ? `double-side-page ${viewerState.pageSize.toLowerCase()}` : 'single-side-page'}>
              <PreviewPage
                  viewerState={viewerState}
                  product={product}
                  fileName={fileName}
                  orderItem={orderItem}
                  stickyPreview={stickyPreview}
                  isMobilePreview={isMobilePreview}
                  overlays={overlays}
                  side="left"
                  coverClass={getCoverClass(viewerState.pageNumber)}
                  overlayIsBack={isEvenPage && isDoubleSided}
                  zoomable={isZoomable}
                  onZoomClick={() => openZoomModal(viewerState.pageNumber)}
                  documentLoaded={documentLoaded}
                  setViewerState={setViewerState}
                  onPdfLoaded={onPdfLoaded}
                  setIsDocumentLoading={setIsDocumentLoading}
              />
              {viewerState.totalPageNumber > 2 && renderPageNumber(viewerState.pageNumber)}
              </div>
            </div>
            )}
            {isMultiPageDoubleSided && viewerState.previewUrl && !stickyPreview &&
                <div className='double-side-wrapper'><div
                    className={isDoubleSided ? `double-side-page ${viewerState.pageSize.toLowerCase()}` : 'single-side-page'}>
                  <PreviewPage
                      viewerState={viewerState}
                      rendererState={{ ...viewerState, pageNumber: isFirstPage ? 1 : viewerState.pageNumber + 1 }}
                      product={product}
                      fileName={fileName}
                      orderItem={orderItem}
                      stickyPreview={stickyPreview}
                      isMobilePreview={isMobilePreview}
                      overlays={overlays}
                      side="right"
                      useFirstWrapperClasses={false}
                      coverClass={getCoverClass(viewerState.pageNumber + 1)}
                      allowBleed={isDoubleSided}
                      zoomable={!stickyPreview && !isMobile && documentLoaded && !isCover(viewerState.pageNumber + 1)}
                      onZoomClick={() => openZoomModal(isFirstPage ? 1 : viewerState.pageNumber + 1)}
                      documentLoaded={documentLoaded}
                      setViewerState={setViewerState}
                      onPdfLoaded={isDoubleSided && isFirstPage ? onPdfLoaded : () => {}}
                      setIsDocumentLoading={() => {}}
                  />
                    {viewerState.totalPageNumber > 2 && renderPageNumber(viewerState.pageNumber + 1)}
                </div>
              </div>
            }
          </div>
          {isDocumentLoading && <div className="pdf-viewer-loading-overlay mobile">
            <div className="pdf-viewer-loader-background"/>
            <LoadingDots/>
          </div>}
          {viewerState.previewUrl && !isMobile && viewerState.totalPageNumber > 1 && <Paginator
            viewerState={viewerState}
            stickyPreview={stickyPreview}
            setPage={setPage}
          />}
        </div>
        {viewerState.previewUrl && isMobile && viewerState.totalPageNumber > 1 && <Paginator
          viewerState={viewerState}
          stickyPreview={stickyPreview}
          setPage={setPage}
        />}
        {documentLoaded && <div className="preview-warning mobile">
            {t('UploadDocument.PreviewWarning')}{isMobile && stickyPreview && isDoubleSided ? ` (${sideTitle})` : ''}
            <div>{getPageDimension()}</div>
            {preflightWarning && !uploadErrorMessage && (
                <div className="preflight-warning" dangerouslySetInnerHTML={{__html: preflightWarning}}/>
            )}
        </div>}
        {viewerState.previewUrl && isMobile && <UploadDocumentButton
          {...{
            setDocumentLoaded, setFileName, fileName, onFormChange, orderItem, properties, product,
            setViewerState, viewerState, uploadErrorMessage, setIsDocumentLoading, setUploadErrorMessage,
            setUploadError, setForceInputFile, onPdfLoaded
          }}
        />}
      </div>
    </div>
    {isMobile && !documentLoaded && uploadErrorMessage && <div className="upload-error-block-bottom">
      <p className="upload-error" dangerouslySetInnerHTML={{__html: uploadErrorMessage}}/>
    </div>}
    {isDocumentLoading && <div className="pdf-viewer-loading-overlay desktop">
      <div className="pdf-viewer-loader-background"/>
      <LoadingDots/>
    </div>}
    {!stickyPreview && !isMobile && <EasyUploadPreviewModal
      isOpen={zoomModalOpen}
      onClose={() => setZoomModalOpen(false)}
      initialPage={zoomInitialPage}
      viewerState={viewerState}
      product={product}
      fileName={fileName}
      orderItem={orderItem}
      overlays={overlays}
    />}
  </>
}
