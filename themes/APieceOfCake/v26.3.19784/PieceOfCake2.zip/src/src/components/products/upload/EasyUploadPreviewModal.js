import React, { useContext, useEffect, useMemo, useRef, useState } from 'react'
import { Modal, ModalBody } from 'reactstrap'
import { RootDocumentContext } from '$themeservices'
import { t } from '$themelocalization'
import { PreviewPage } from './PreviewPage'
import { Paginator } from '../Paginatior'
import { getUploadedFileDimensionsText } from './easyUploadUtils'
import './EasyUploadPreviewModal.scss'

export const EasyUploadPreviewModal = ({
  isOpen,
  onClose,
  initialPage,
  viewerState,
  product,
  fileName,
  orderItem,
  overlays,
}) => {
  const { rootElement } = useContext(RootDocumentContext)()
  const [page, setPage] = useState(initialPage || 1)
  const [zoomed, setZoomed] = useState(false)
  const targetRef = useRef(null)
  const contentRef = useRef(null)

  useEffect(() => {
    if (isOpen) {
      setPage(initialPage || 1)
      setZoomed(false)
    }
  }, [isOpen, initialPage])

  const modalViewerState = useMemo(
    () => ({ ...viewerState, pageNumber: page, scale: 3 }),
    [viewerState, page]
  )

  if (!isOpen) return null

  const isDoubleSided = viewerState.doubleSidedPrinting > 1
  const isEvenPage = page % 2 === 0
  const sideSuffix = isDoubleSided && viewerState.totalPageNumber > 2 ? ` (${t(`UploadDocument.${isEvenPage ? 'Back' : 'Front'}`)})` : ''

  const changePage = (newPage) => {
    setZoomed(false)
    setPage(newPage)
  }

  const applyOrigin = (e) => {
    if (!targetRef.current || !contentRef.current) return
    const rect = targetRef.current.getBoundingClientRect()
    const x = Math.min(100, Math.max(0, ((e.clientX - rect.left) / rect.width) * 100))
    const y = Math.min(100, Math.max(0, ((e.clientY - rect.top) / rect.height) * 100))
    contentRef.current.style.transformOrigin = `${x}% ${y}%`
  }

  const toggleZoom = (e) => {
    e.stopPropagation()
    if (zoomed) {
      setZoomed(false)
      return
    }
    applyOrigin(e)
    setZoomed(true)
  }

  const onMove = (e) => {
    if (zoomed) applyOrigin(e)
  }

  const clearZoom = () => setZoomed(false)

  return (
    <Modal toggle={onClose} isOpen={isOpen} modalClassName="eu-preview-modal" container={rootElement}>
      <div className="eu-preview-close" role="button" tabIndex={0} onClick={onClose}
           onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onClose() } }}
           aria-label={t('General.Close')}>×</div>
      <ModalBody>
        <div className="eu-preview-body" onClick={clearZoom}>
          <div className="eu-preview-title">{t('UploadDocument.PreviewWarning')}{sideSuffix}{' '}
            <span className="no-wrap">{getUploadedFileDimensionsText(product, viewerState)}</span></div>
          <div className="eu-preview-stage">
            <div ref={targetRef}
                 className={`eu-preview-zoom-target ${zoomed ? 'zoomed' : ''}`}
                 onClick={toggleZoom}
                 onMouseMove={onMove}>
              <div ref={contentRef} className="eu-preview-zoom-content">
              <div className="pdf-viewer-container loaded">
                <div className="preview-wrapper">
                  <div className="canvas-container">
                    <div className="pages-wrapper">
                      <div className="single-side-wrapper">
                        <div className="single-side-page">
                          <PreviewPage
                            viewerState={modalViewerState}
                            product={product}
                            fileName={fileName}
                            orderItem={orderItem}
                            stickyPreview={false}
                            overlays={overlays}
                            side="left"
                            overlayIsBack={isEvenPage && isDoubleSided}
                            skipThumbnail={true}
                            disableCoverPages={true}
                            documentLoaded={true}
                            setViewerState={() => {}}
                            onPdfLoaded={() => {}}
                            setIsDocumentLoading={() => {}}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              </div>
            </div>
          </div>
          {viewerState.totalPageNumber > 1 &&
            <div className="eu-preview-paginator" onClick={(e) => e.stopPropagation()}>
              <Paginator viewerState={modalViewerState} setPage={changePage} stickyPreview={true}/>
            </div>}
        </div>
      </ModalBody>
    </Modal>
  )
}