import { convertToMM, PT_TO_MM, parsePageSize as parsePageSizeUtil } from '$themeservices'

const parsePageSize = (pageSize, product) => parsePageSizeUtil(pageSize, product)

export const getShowBleed = (viewerState, product, stickyPreview, isMobilePreview) => {
  const showTrimMarks = (!stickyPreview || isMobilePreview) && product?.Attributes?.find((attr) => attr.Name === 'EasyUploadShowTrimMarks')
  return !!(viewerState?.metaData?.DocumentBoxes?.Trim && showTrimMarks?.Value?.toLowerCase() === 'true')
}

export const calculatePageSizeWithBleed = (viewerState, product, showBleed) => {
  if (!viewerState.pageSize || !viewerState.metaData) {
    return { width: null, height: null }
  }

  let selectedWidth, selectedHeight
  const originalWidth = viewerState.metaData.Width
  const originalHeight = viewerState.metaData.Height

  if (viewerState.pageSize === 'Auto') {
    selectedWidth = originalWidth
    selectedHeight = originalHeight
  } else {
    const parsed = parsePageSize(viewerState.pageSize, product)
    const widthMM = convertToMM(parsed.width, parsed.unit)
    const heightMM = convertToMM(parsed.height, parsed.unit)
    selectedWidth = widthMM / PT_TO_MM
    selectedHeight = heightMM / PT_TO_MM

    if (viewerState.orientation === 'landscape') {
      [selectedWidth, selectedHeight] = [selectedHeight, selectedWidth]
    }
  }

  if (viewerState.FitMode === 'Fit' && showBleed && viewerState.metaData.DocumentBoxes && viewerState.pageSize !== 'Auto') {
    const { Trim, Media } = viewerState.metaData.DocumentBoxes

    const scaleX = selectedWidth / originalWidth
    const scaleY = selectedHeight / originalHeight

    const bleedLeft = Math.abs(Trim.Left - Media.Left)
    const bleedRight = Math.abs(Trim.Right - Media.Right)
    const bleedTop = Math.abs(Trim.Top - Media.Top)
    const bleedBottom = Math.abs(Trim.Bottom - Media.Bottom)

    const scaledBleedLeft = bleedLeft * scaleX
    const scaledBleedRight = bleedRight * scaleX
    const scaledBleedTop = bleedTop * scaleY
    const scaledBleedBottom = bleedBottom * scaleY

    selectedWidth = selectedWidth + scaledBleedLeft + scaledBleedRight
    selectedHeight = selectedHeight + scaledBleedTop + scaledBleedBottom
  }

  return { width: selectedWidth, height: selectedHeight }
}

export const calculateCanvasSize = (viewerState, product) => {
  if (!viewerState.metaData || !viewerState.pageSize) {
    return { width: null, height: null }
  }

  let sheetWidth, sheetHeight

  if (viewerState.pageSize === 'Auto') {
    sheetWidth = viewerState.metaData.Width * PT_TO_MM
    sheetHeight = viewerState.metaData.Height * PT_TO_MM
  } else {
    const parsed = parsePageSize(viewerState.pageSize, product)
    sheetWidth = convertToMM(parsed.width, parsed.unit)
    sheetHeight = convertToMM(parsed.height, parsed.unit)

    if (viewerState.orientation === 'landscape') {
      [sheetWidth, sheetHeight] = [sheetHeight, sheetWidth]
    }
  }

  const originalWidthPT = viewerState.metaData.Width
  const originalHeightPT = viewerState.metaData.Height

  const widthMM = originalWidthPT * PT_TO_MM
  const heightMM = originalHeightPT * PT_TO_MM

  const widthPercent = (widthMM / sheetWidth) * 100
  const heightPercent = (heightMM / sheetHeight) * 100

  return { width: widthPercent, height: heightPercent }
}

export const getPageStyle = (viewerState, product, showBleed) => {
  const result = {}
  const { width, height } = calculatePageSizeWithBleed(viewerState, product, showBleed)

  if (width && height) {
    result['aspect-ratio'] = `${width}/${height}`
    result['--page-ratio'] = width / height
  } else if (viewerState.pageSize) {
    if (viewerState.pageSize === 'Auto') {
      const w = viewerState.metaData?.Width || 1
      const h = viewerState.metaData?.Height || 1
      result['aspect-ratio'] = `${w}/${h}`
      result['--page-ratio'] = w / h
    } else {
      const parsed = parsePageSize(viewerState.pageSize, product)
      const w = parsed.width
      const h = parsed.height
      result['aspect-ratio'] = viewerState.orientation === 'landscape' ? `${h}/${w}` : `${w}/${h}`
      result['--page-ratio'] = viewerState.orientation === 'landscape' ? h / w : w / h
    }
  }

  if (viewerState.paperColor) {
    result['background-color'] = viewerState.paperColor
  }
  return result
}

export const getFlipPage = (viewerState) => {
  const isEvenPage = viewerState.pageNumber % 2 === 0
  return viewerState.doubleSidedPrinting === 3 && isEvenPage && viewerState.pageNumber > 1 ? 'double-sided-flipped' : ''
}

export const getWrapperClasses = (viewerState) => {
  const doubleSidedBackPage = viewerState.totalPageNumber === 2 && viewerState.pageNumber === 2 && viewerState.doubleSidedPrinting > 1

  return [
    'canvas-wrapper',
    viewerState.orientation,
    doubleSidedBackPage ? viewerState.corners.split(' ').join('-back ') + '-back' : viewerState.corners,
    viewerState.lamination,
    viewerState.pageSize
  ].filter(c => !!c).join(' ')
}

export const getFirstWrapperClasses = (viewerState) => {
  const isEvenPage = viewerState.pageNumber % 2 === 0
  return [getWrapperClasses(viewerState), getFlipPage(viewerState), isEvenPage && viewerState.drilling ? 'drilling' : ''].join(' ')
}