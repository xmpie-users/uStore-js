import { useEffect, useState } from 'react'
import './ProductDeliveryMethod.scss'
import { RadioGroup } from '$core-components'
import { t } from '$themelocalization'

/**
 * A component that is
 *
 * @param {string} className -
 * @param {object} productModel -
 * @param {function} onDeliveryChange -
 * @param {number} currentDeliveryMethod
 * @param {string} currentDeliveryServiceID
 * @param {array} deliveryServices
 *
 */

const ProductDeliveryMethod = ({ className, productModel, onDeliveryChange, currentDeliveryMethod, currentDeliveryServiceID, deliveryServices }) => {
  const [selectedDelivery, setSelectedDelivery] = useState(currentDeliveryServiceID ? currentDeliveryServiceID : currentDeliveryMethod)

  useEffect(() => {
    onDeliveryChange && onDeliveryChange(currentDeliveryMethod, currentDeliveryServiceID, true)
  }, [])

  useEffect(() => {
    setSelectedDelivery(currentDeliveryServiceID ? currentDeliveryServiceID : currentDeliveryMethod)
  }, [currentDeliveryServiceID, currentDeliveryMethod])

  const onDeliveryChanged = (value, obj) => {
    setSelectedDelivery(value)
    onDeliveryChange && onDeliveryChange(obj && obj.isMailing ? 2 : value, obj && obj.isMailing ? value : null)
  }

  if (!productModel) { // || !isMultiple || !productModel.Configuration.Delivery.Shipping.Enabled && !productModel.Configuration.Delivery.Mailing.Enabled) {
    return null
  }

  const deliveryOptions = [
    {
      id: 'ship',
      value: 1,
      label: t('product.shipping'),
      enabled: productModel.Configuration && productModel.Configuration.Delivery && productModel.Configuration.Delivery.Shipping.Enabled,
      isMailing: false,
    },
    // { value: 2, label: 'Mail Drop', enabled: productModel.Configuration.Delivery.Mailing.Enabled }
  ]
  if (deliveryServices && deliveryServices.MailingServices && deliveryServices.MailingServices.length) {
    deliveryServices.MailingServices.forEach((service) => {
      deliveryOptions.push(
        {
          id: 'mail',
          value: service.ID,
          label: service.Name,
          enabled: productModel.Configuration && productModel.Configuration.Delivery && productModel.Configuration.Delivery.Mailing.Enabled,
          isMailing: true,
        })
    })
  }

  const enabledOptions = deliveryOptions.filter(item => item.enabled)

  if (!enabledOptions || enabledOptions.length <= 1) {
    return null
  }

  return <div className={`${className} product-delivery-method`}>
    <div className='delivery-method'>
      <div className='delivery-method-label'>
        <span>{t('product.delivery')}</span><span className='required-indicator'>*</span>
      </div>
      <RadioGroup
        groupName='delivery'
        className={'static-delivery'}
        options={deliveryOptions.filter(d => d.enabled)}
        selectedValue={selectedDelivery}
        onChange={onDeliveryChanged}
      />
    </div>
  </div>
}

export default ProductDeliveryMethod
