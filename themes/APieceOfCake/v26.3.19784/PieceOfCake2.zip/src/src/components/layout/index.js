import { useEffect, useRef } from 'react'
import HeadSEO from './HeadSEO'
import Header from './Header'
import Footer from './Footer'
import './Layout.scss'
import CookiesRibbon from "./CookiesRibbon";
import ResizeObserver from "resize-observer-polyfill"
import RouteChangeListener from './RouteChangeListener'
/**
 * The main page wrapper - contains the Header and Footer and gets children as the main content
 *
 * @param {object} state - state of store
 * @param {component} children - React components to be presented between header and footer
 * @param {string} [className] - class name to append to the container div
 */

const _debounce = function (ms, fn) {
  var timer;
  return function () {
    clearTimeout(timer)
    var args = Array.prototype.slice.call(arguments)
    args.unshift(this)
    timer = setTimeout(fn.bind.apply(fn, args), ms)
  };
};

let currentHeight = 0

const Layout = ({ state, children, className, dataPage, dataEntityType, dataEntityGuid }) => {
  const resizeElement = useRef(null)
  const isConnectStoreRef = useRef(false)

  const storeType = (state && state.currentStore) ? state.currentStore.StoreType : null
  if (storeType === 3) {
    // connect store - hide header and footer.
    isConnectStoreRef.current = true
  }
  const isConnectStore = isConnectStoreRef.current

  useEffect(() => {
    if (!isConnectStore) return

    const resizeObserver = new ResizeObserver(_debounce(300, function (entries) {
      entries.forEach(entry => {
        if (currentHeight !== entry.contentRect.height) {
          currentHeight = entry.contentRect.height
          console.log('USTORE_CONNECT_RESIZE height: ' + entry.contentRect.height)
          window.parent.postMessage({
            type: '@USTORE_CONNECT_RESIZE',
            data: {
              height: entry.contentRect.height,
              width: entry.contentRect.width
            }
          }, '*')
        }
      })
    }))

    if (resizeElement.current) resizeObserver.observe(resizeElement.current);

    return () => resizeObserver.disconnect()
  }, [isConnectStore])

  let isPreviewMode = false
  let url = ''
  try {
    // wrapping in try catch so that in cross-domain (connect store) it will be ignored.
    url = window.top.location.href
  } catch (error) { }

  if (url && (url.includes('MobilePreview.aspx') || url.includes('ThemeCustomization.aspx')))
    isPreviewMode = true

  const showHeaderFooter = storeType === 4 ?
    state.currentStore.Attributes.find(attr => attr.Name === 'ShowHeaderAndFooter' && attr.Value === 'True') :
    (!isConnectStore || isPreviewMode)

  return (
    <div>
      <HeadSEO {...state} />
      <div
        className={`layout ${className ? className : ''} ${isPreviewMode ? 'preview' : ''} ${!showHeaderFooter ? 'connect' : ''}`}
        data-page={dataPage}
        {...(dataEntityType && dataEntityGuid ? { [`data-${dataEntityType}-guid`]: dataEntityGuid } : {})}
      >
        {showHeaderFooter && <Header {...state} />}
        <div className="main-content" role="main" ref={resizeElement}>
          {children}
        </div>
        {showHeaderFooter && <Footer />}
        {state.customState && state.currentStore && <CookiesRibbon showRibbon={state.customState.showCookieRibbon} />}
      </div>
      <RouteChangeListener/>
    </div>
  )
}

export default Layout
