import React from 'react'
import Legacy from './Legacy'

const Recipient = (props) => {
  return <Legacy {...props}/>
}

export default Recipient
