const theme = process.env.THEME_PAGES || 'AquaBlue'
const fs = require('fs')
const path = require('path')
const rpath = path.join.bind(path, __dirname)

const xmpieBuild = fs.existsSync(rpath('../../.xmpie'))
const { features } = require(rpath(xmpieBuild ? `../../themes/${theme}/config.json` : '../../../config.json'))
const featuresFileName = rpath('../../features.json')
fs.writeFileSync(featuresFileName, JSON.stringify(features, null, '  '), { encoding: 'utf-8' })