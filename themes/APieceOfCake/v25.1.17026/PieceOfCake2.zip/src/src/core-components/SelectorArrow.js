import React from 'react'
import Icon from './Icon'

const SelectorArrow = () => (
    <Icon
        name='arrowDown.svg'
        width="16px"
        height="20px"
        wrapperClassName="select-icon"
    />
)

export default SelectorArrow