import React from 'react'
import Legacy from './Legacy'

const CheckoutFinal = (props) => {
  return <Legacy {...props}/>
}

export default CheckoutFinal
