import React from 'react'
import Legacy from './Legacy'

const CheckoutPaymentSubmission = (props) => {
  return <Legacy {...props}/>
}

export default CheckoutPaymentSubmission
