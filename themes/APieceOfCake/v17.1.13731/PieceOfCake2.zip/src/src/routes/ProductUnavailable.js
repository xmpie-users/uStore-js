import React, { Component } from 'react'
import Legacy from './Legacy'

export default class ProductUnavailable extends Component {
  render () {
    return <Legacy {...this.props}/>
  }
}
