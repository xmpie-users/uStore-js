export const getConfig = () => ({
  publicRuntimeConfig: {
    assetPrefix: '/ustorethemes/PieceOfCake2',
    apiUrl: '/uStoreRestAPI',
    classicUrl: '/ustore',
    themeCustomizationUrl: '/uStoreThemeCustomizations',
    serverDomain: 'http://localhost:5000'
  }
})
