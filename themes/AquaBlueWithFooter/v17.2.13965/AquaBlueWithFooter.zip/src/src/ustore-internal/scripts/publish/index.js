
module.exports = {
  ...require('./included-files'),
  execCommandInTheme: require('./command'),
  parseVariables: require('./parse-variables'),
  utils: require('./utils'),
}