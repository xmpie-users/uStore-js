import React from 'react'
import Legacy from './Legacy'

const MyRecipientLists = (props) => {
  return <Legacy {...props}/>
}

export default MyRecipientLists
