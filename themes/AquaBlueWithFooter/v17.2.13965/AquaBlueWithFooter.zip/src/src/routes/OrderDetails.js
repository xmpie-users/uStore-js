import React from 'react'
import Legacy from './Legacy'

const OrderDetails = (props) => {
  return <Legacy {...props}/>
}

export default OrderDetails
