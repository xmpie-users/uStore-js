import React from 'react'
import Legacy from './Legacy'

const OrderHistory = (props) => {
  return <Legacy {...props}/>
}

export default OrderHistory
