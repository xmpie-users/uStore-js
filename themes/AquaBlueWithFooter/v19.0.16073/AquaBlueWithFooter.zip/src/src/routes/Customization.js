import React from 'react'
import Legacy from './Legacy'

const Customization = (props) => {
  return <Legacy {...props}/>
}

export default Customization
