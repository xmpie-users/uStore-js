import React from 'react'
import Legacy from './Legacy'

const FileSubmission = (props) => {
  return <Legacy {...props}/>
}

export default FileSubmission
