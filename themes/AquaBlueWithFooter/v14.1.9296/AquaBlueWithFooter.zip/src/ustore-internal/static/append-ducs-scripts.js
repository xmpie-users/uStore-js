if (xmpie_uStore_DUCs) {
  xmpie_uStore_DUCs.forEach(duc => {
    document.writeln(`<script src="${duc.baseUrl}/main.min.js?rand=${Math.random()}" type="application/javascript"></script>`)
    document.writeln(`<link href="${duc.baseUrl}/main.css?rand=${Math.random()}" rel="stylesheet"/>`)
  })
}