import React from 'react'
import Legacy from './Legacy'

const OrderFinalStep = (props) => {
  return <Legacy {...props}/>
}

export default OrderFinalStep
