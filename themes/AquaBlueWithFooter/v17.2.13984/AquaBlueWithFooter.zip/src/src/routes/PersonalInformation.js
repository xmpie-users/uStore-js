import React from 'react'
import Legacy from './Legacy'

const PersonalInformation = (props) => {
  return <Legacy {...props}/>
}

export default PersonalInformation
