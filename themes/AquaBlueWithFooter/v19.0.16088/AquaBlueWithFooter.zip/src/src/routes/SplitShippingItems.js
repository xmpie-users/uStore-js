import React from 'react'
import Legacy from './Legacy'

const SplitShippingItems = (props) => {
  return <Legacy {...props}/>
}

export default SplitShippingItems
