var ducConfig = [
  {
    name: 'TextInput',
    assets: [
      "/ducs/TextInputDuc.duc.js",
    ]
  },
  {
    name: 'DropDown',
    assets: [
      "/ducs/DropDownDuc.duc.js",
    ]
  },
  {
    name: 'DateTimePicker',
    assets: [
      "/ducs/DateTimePickerDuc.duc.js",
    ]
  },
  {
    name: 'FileUpload',
    assets: [
      "/ducs/FileUploadDuc.duc.js",
    ]
  },
]



