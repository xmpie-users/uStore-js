import React, { Component } from 'react'
import Legacy from './Legacy'

export default class OrderHistory extends Component {
  render () {
    return <Legacy {...this.props}/>
  }
}
