export const getConfig = () => ({
  publicRuntimeConfig: {
    assetPrefix: '/ustorethemes/AquaBlueWithFooter',
    apiUrl: '/uStoreRestAPI',
    classicUrl: '/ustore',
    themeCustomizationUrl: '/uStoreThemeCustomizations',
    serverDomain: 'http://localhost:5000'
  }
})
