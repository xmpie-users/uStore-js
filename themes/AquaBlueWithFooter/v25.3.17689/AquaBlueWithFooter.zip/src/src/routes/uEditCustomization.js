import React from 'react'
import Legacy from './Legacy'

const uEditCustomization = (props) => {
  return <Legacy {...props} />
}

export default uEditCustomization
