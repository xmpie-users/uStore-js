import {createContext} from 'react'

export const RootDocumentContext = createContext('')
