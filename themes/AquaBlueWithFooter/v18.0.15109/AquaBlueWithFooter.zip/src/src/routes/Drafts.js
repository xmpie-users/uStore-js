import React from 'react'
import Legacy from './Legacy'

const Drafts = (props) => {
  return <Legacy {...props}/>
}

export default Drafts
