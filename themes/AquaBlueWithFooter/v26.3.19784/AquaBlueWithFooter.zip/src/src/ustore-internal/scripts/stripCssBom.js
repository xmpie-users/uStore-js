/**
 * Strips UTF-8 BOM (Byte Order Mark) characters from CSS files.
 *
 * This fixes an issue where webpack's MiniCssExtractPlugin introduces BOM
 * characters during CSS chunk concatenation, which can break CSS parsing
 * in browsers when the BOM appears mid-file.
 */

const fs = require('fs')
const path = require('path')
const clc = require('cli-color')

// UTF-8 BOM as a Buffer
const BOM = Buffer.from([0xEF, 0xBB, 0xBF])

/**
 * Strips all BOM occurrences from a file
 * @param {string} filePath - Path to the file to process
 * @returns {number} - Number of BOMs removed
 */
function stripBomFromFile(filePath) {
  const content = fs.readFileSync(filePath)
  let bomCount = 0
  let position = 0
  const chunks = []

  while (position < content.length) {
    const bomIndex = content.indexOf(BOM, position)
    if (bomIndex === -1) {
      // No more BOMs, add the rest of the content
      chunks.push(content.slice(position))
      break
    }
    // Add content before the BOM
    if (bomIndex > position) {
      chunks.push(content.slice(position, bomIndex))
    }
    bomCount++
    position = bomIndex + BOM.length
  }

  if (bomCount > 0) {
    const cleanContent = Buffer.concat(chunks)
    fs.writeFileSync(filePath, cleanContent)
  }

  return bomCount
}

/**
 * Strips BOMs from all CSS files in a directory
 * @param {string} directory - Directory to process
 * @param {boolean} recursive - Whether to process subdirectories
 * @returns {object} - Summary of files processed
 */
function stripBomFromDirectory(directory, recursive = true) {
  const results = {
    filesProcessed: 0,
    filesWithBom: 0,
    totalBomsRemoved: 0
  }

  function processDirectory(dir) {
    const entries = fs.readdirSync(dir, { withFileTypes: true })

    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name)

      if (entry.isDirectory() && recursive) {
        processDirectory(fullPath)
      } else if (entry.isFile() && entry.name.endsWith('.css')) {
        results.filesProcessed++
        const bomsRemoved = stripBomFromFile(fullPath)
        if (bomsRemoved > 0) {
          results.filesWithBom++
          results.totalBomsRemoved += bomsRemoved
          console.log(clc.yellow(`  Removed ${bomsRemoved} BOM(s) from: ${path.relative(process.cwd(), fullPath)}`))
        }
      }
    }
  }

  if (fs.existsSync(directory)) {
    processDirectory(directory)
  }

  return results
}

/**
 * Main function to strip BOMs from the build output
 * @param {string} outDir - The output directory (default: './out')
 */
function main(outDir = './out') {
  console.log(clc.green('Stripping BOM characters from CSS files...'))

  const cssDir = path.join(outDir, 'static', 'css')
  const results = stripBomFromDirectory(cssDir)

  if (results.totalBomsRemoved > 0) {
    console.log(clc.green(`Done: Removed ${results.totalBomsRemoved} BOM(s) from ${results.filesWithBom} file(s)`))
  } else {
    console.log(clc.green('Done: No BOM characters found'))
  }

  return results
}

module.exports = {
  stripBomFromFile,
  stripBomFromDirectory,
  main
}

// Allow running directly from command line
if (require.main === module) {
  const outDir = process.argv[2] || './out'
  main(outDir)
}
