# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is a custom DUC (Dynamic User Control) for XMPie uStore NG. DUCs are React components that provide custom input controls for uStore product properties. This specific DUC implements a text input and label that shows the character count and prevents input beyond a set limit.

## Commands

```bash
# Install dependencies
npm install

# Development mode (watches for changes)
npm start

# Build for production (creates ZIP in dist/)
npm run build

# Run tests
npx jest

# Run a single test file
npx jest path/to/test.js
```

## Architecture

### DUC File Convention
- DUC components must be named `*.duc.js` (e.g., `TextWithCount.duc.js`)
- The build system auto-discovers all `*.duc.js` files in the root directory
- Each DUC must register itself with `window.uStoreDucs.push()` including `name`, `component`, `displayName`, and `configSample`

### DUC Registration Pattern
```javascript
if (typeof window !== 'undefined') {
    window.uStoreDucs = window.uStoreDucs || []
    window.uStoreDucs.push({
        name: 'ComponentName',       // No spaces, matches class name
        component: ComponentName,
        displayName: 'Display Name', // Shown in uStore admin
        configSample: {}             // Default configuration JSON
    })
}
export default ComponentName
```

### Required DUC Props Handling
DUCs receive these props from uStore forms and must handle them appropriately:
- `readonly`, `disabled`, `required` - Form state props
- `value` - Current field value
- `onChange(newValue)` - Call to update value
- `onBlur(id, value)` - Call on focus lost
- `uiSchema` - Configuration from `ui:options.custom`
- `jsonschema` - Validation schema

### Build Output
- `npm run build` creates `dist/{DucName}.zip` containing `main.min.js`, `config.json`, and `thumbnail.png`
- A `thumbnail.png` file is required in the project root for builds to succeed

### External Dependencies
React, ReactDOM, and PropTypes are externalized - they're provided by the uStore NG runtime and not bundled.

### Styles
- SCSS files go in `styles/` directory
- `_theme.scss` provides responsive breakpoint variables ($xs, $sm, $md, $lg, $xl)
