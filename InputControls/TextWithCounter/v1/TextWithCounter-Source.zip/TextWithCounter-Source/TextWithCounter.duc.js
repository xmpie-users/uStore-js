import React, { Component } from 'react'
import './styles/text-with-counter.scss'

class TextWithCounter extends Component {
    constructor(props) {
        super(props)
        this.state = {
            rowsHigh: 3,
            maxCharacterLength: 200,
            countMessage: "",
            maxErrorMessage: "",
            warningMessageColor: "DarkOrange",
            warnRemainingCount: "10",
            displayMessage: "",
            initialValue: "",
            textToShow: props.value || ""
        }
    }

    componentDidMount() {
        const {value, uiSchema: {'ui:options': {custom: {maxCharacterLength, countMessage, maxErrorMessage, rowsHigh, warningMessageColor, warnRemainingCount, initialValue}}}} = this.props

        const textToShow = value || ""
        const plural = textToShow.length === 1 ? '' : 's'
        const cMessage = countMessage.replace('{value}', textToShow.length).replace('{s}', plural)

        this.setState({
            rowsHigh: rowsHigh || 3,
            maxCharacterLength: maxCharacterLength,
            countMessage: countMessage,
            maxErrorMessage: maxErrorMessage,
            warningMessageColor: warningMessageColor || "DarkOrange",
            warnRemainingCount: warnRemainingCount || 10,
            initialValue: value,
            textToShow: textToShow,
            displayMessage: cMessage
        })
    }

    updateCounter = (e) => {
        const { maxCharacterLength, countMessage, maxErrorMessage, initialValue, warnRemainingCount } = this.state

        let textToShow = initialValue || e.target.value
        if (textToShow.length > maxCharacterLength) {
            textToShow = textToShow.substring(0, maxCharacterLength)
        }

        const plural = textToShow.length === 1 ? '' : 's'
        const cMessage = countMessage.replace('{value}', textToShow.length).replace('{s}', plural)
        const maxMessage = maxErrorMessage.replace('{value}', maxCharacterLength)

        let displayMessage = cMessage
        if (textToShow.length >= maxCharacterLength - warnRemainingCount) {
            displayMessage += ' ' + maxMessage
        } 

        this.setState({ displayMessage, textToShow })

        clearTimeout(this.onChangeTimeout)
        this.onChangeTimeout = setTimeout(() => {
            this.props.onChange(textToShow)
        }, 2000)
    }

    render() {
        const {
            options = {
                readonly: false,
            },
            disabled,
            required,
            readonly,
        } = this.props

        const { displayMessage, textToShow, rowsHigh: rowsHigh, maxCharacterLength, warningMessageColor, warnRemainingCount } = this.state

        let labelColor = ''
        if (textToShow.length >= maxCharacterLength) {
            labelColor = 'Green'
        } else if (textToShow.length >= maxCharacterLength - warnRemainingCount) {
            labelColor = warningMessageColor
        }

        return (
            <div>
                <div className='text-with-counter-div'>
                    <textarea onChange={this.updateCounter} value={textToShow} rows={rowsHigh} />
                    <label className='counterLabel' style={{ color: labelColor }}>{displayMessage}</label>
                </div>
            </div>
        )
    }
}

if (typeof window !== 'undefined') {
    window.uStoreDucs = window.uStoreDucs || []
    window.uStoreDucs.push({
        name: 'TextWithCounter',
        component: TextWithCounter,
        displayName: 'Textarea with counter',
        configSample: {
            rowsHigh: 3,
            maxCharacterLength: 200,
            countMessage: "{value} character{s}.",
            maxErrorMessage: "A maximum of {value} characters is permitted.",
            warningMessageColor: "DarkOrange",
            warnRemainingCount: 10
        },
    })
}

export default TextWithCounter
