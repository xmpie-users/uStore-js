# Subordinate Select Input Control (DUC) for uStore v25.2 and later

This sample Input Control implements a series of dependent dropdown lists based on the configuration JSON either entered into uStore customization step or via a URL.

Configuration instructions for this Input control are available [here]().

### Prerequisites to develop new Input Controls or modify this one
* Use node js version 16 and above.

### Steps to modify and build this Input Control

1. Extract the downloaded zip to a new directory.
2. In the new directory do `npm install`.
3. In the new directory make changes to the SubordinateSelect.duc.js as required. (To create a new Input Control instead of modify this one, refer to the instructions in the Input Control Development Guide that shows how to rename the control.)
4. When finished editing, save the files and in the terminal run `npm run build`.
5. When script is done you will find a zip file in `dist` directory. The file should be named SubordinateSelect.zip.
6. Upload the zip to your uStore server Presets > Input Control Manangement either:

    a. Select existing Subordinate Select control and click "Replace", or if it has not been installed previously:
    
    b. Click "New Input Control".

### More documentation

To develop a DUC (Input Control) the full development guide is available [here](https://github.com/XMPieLab/uStore-NG/wiki/Input-Control-Development-Guide).