import React, { Component } from 'react'
import './styles/dropdown-with-other.scss'

class DropDownWithOther extends Component {
    constructor(props) {
        super(props)
        this.state = {
            inputValue: '',
            otherVisible: false,
            availableOptions: [],
            selectedOption: "",
            addSelectText: false,
            selectText: "",
            optionsArr: [],
        }
    }

    componentDidMount() {
        const {value, uiSchema: {'ui:options': {custom: {availableOptions, selectedOption, selectText, addSelectText}}}} = this.props
        var optionsArr = []
        if(addSelectText)
            optionsArr = [...[selectText], ...availableOptions]
        else
            optionsArr = [...availableOptions]
        if (!optionsArr.includes('Other'))
            optionsArr.push('Other')
        const initialValue = value || selectedOption || ''
        const isOtherValue = initialValue && !optionsArr.includes(initialValue)
        this.setState({
            inputValue: initialValue,
            otherVisible: isOtherValue,
            availableOptions: availableOptions,
            selectedOption: selectedOption,
            selectText: selectText,
            addSelectText: addSelectText,
            optionsArr: optionsArr
        }, () => {
			setTimeout(() => {
				if (initialValue) {
					this.props.onChange(initialValue)
				}
			}, 500)
        })
    }

    onInputChanged = (e) => {
        const newValue = e.target.value
        this.setState({inputValue: newValue})
        this.props.onChange(newValue)
    }

    onSelectChanged = (e) => {
        const newValue = e.target.value
        if (newValue === 'Other') {
            //show the input field
            this.setState({otherVisible: true})
        } else {
            //hide the input field
            this.setState({otherVisible: false})
            this.setState({inputValue: newValue})
            this.props.onChange(newValue)
        }
    }

    handleOnBlur = () => {
        const {onBlur, id} = this.props
        onBlur(id, this.state.inputValue)
    }

    render() {
        const {
            options = {
                readonly: false,
            },
            disabled,
            required,
            readonly,
        } = this.props

        const {inputValue} = this.state
        const {otherVisible} = this.state
        const {availableOptions} = this.state
        const {selectText} = this.state
        const {addSelectText} = this.state
        const {optionsArr} = this.state

        return (
            <div>
                <div className='dropdown-with-other-div'>
                    <select
                        name="ddl"
                        required={required || options.required}
                        onChange={this.onSelectChanged}
                        className="form-control dropdown-with-other-select"
                        disabled={readonly || options.readonly || disabled}
                        onBlur={this.handleOnBlur}
                        value={otherVisible ? 'Other' : inputValue}
                    >
                        {optionsArr.map((option, index) => (
                            <option key={index}
                                value={addSelectText && option === selectText ? '' : option}
                                disabled={addSelectText && option === selectText}>
                                {option}
                            </option>
                        ))}
                    </select>
                </div>
                {otherVisible && (
                    <div>Other: <input
                        name="ddl-other"
                        type="text"
                        required={required || options.required}
                        onChange={this.onInputChanged}
                        className="form-control dropdown-with-other-input"
                        value={inputValue}
                        disabled={readonly || options.readonly || disabled}
                        onBlur={this.handleOnBlur}
                    />
                    </div>
                )}
            </div>
        )
    }
}

if (typeof window !== 'undefined') {
    window.uStoreDucs = window.uStoreDucs || []
    window.uStoreDucs.push({
        name: 'DropDownWithOther',
        component: DropDownWithOther,
        displayName: 'Dropdown list with Other',
        configSample: {
            availableOptions: ['London', 'New York', 'Hong Kong', 'Sydney'],
            selectedOption: "New York",
            addSelectText: false,
            selectText: "-- select an option --"
        },
    })
}

export default DropDownWithOther
