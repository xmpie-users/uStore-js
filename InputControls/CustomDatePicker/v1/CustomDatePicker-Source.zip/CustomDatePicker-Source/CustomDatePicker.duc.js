import React, { Component } from 'react'
import DatePicker from 'react-datepicker'
import 'react-datepicker/dist/react-datepicker.css'
import './styles/custom-date-picker.scss'

class CustomDatePicker extends Component {
    constructor(props) {
        super(props)
        this.state = {
            selectedDate: null,
            configured: false,
            style: 'date',
            theme: 'light',
            dateFormat: 'dd/MM/yyyy',
            minDate: null,
            maxDate: null,
            disableWeekends: true,
            weekendDays: [6, 0],
            holidays: [],
            timeFormat: 24,
            minTime: null,
            maxTime: null,
            timeInterval: 15,
            disableLunch: false,
            lunchStart: '12:00',
            lunchMinutes: 30,
            displayMode: 'click'
        }
    }

    componentDidMount() {
        const { value, uiSchema } = this.props
        const custom = (uiSchema && uiSchema['ui:options'] && uiSchema['ui:options'].custom) || {}

        const style = custom.style || 'date'
        const theme = custom.theme || 'light'
        const dateFormat = custom.dateFormat || 'dd/MM/yyyy'
        const disableWeekends = custom.disableWeekends !== undefined ? custom.disableWeekends : true
        const weekendDays = custom.weekendDays || [6, 0]
        const holidays = (custom.holidays || []).map(h => this.parseConfigDate(h)).filter(Boolean)
        const timeFormat = custom.timeFormat || 24
        const minTime = this.parseConfigTime(custom.minTime || '09:00')
        const maxTime = this.parseConfigTime(custom.maxTime || '17:00')
        const timeInterval = custom.timeInterval || 15
        const disableLunch = custom.disableLunch === true || custom.disableLunch === 'true'
        const lunchStart = custom.lunchStart || '12:00'
        const lunchMinutes = custom.lunchMinutes || 30
        const displayMode = custom.displayMode === 'inline' ? 'inline' : 'click'
        const minDate = custom.minDate ? this.parseConfigDate(custom.minDate) : null
        const maxDate = custom.maxDate ? this.parseConfigDate(custom.maxDate) : null

        // Determine initial selected date
        let selectedDate = null
        if (value) {
            selectedDate = this.parseDotNetFormat(value, dateFormat)
        }
        if (!selectedDate && custom.initialDate) {
            selectedDate = this.parseConfigDate(custom.initialDate)
        }

        // For time/datetime modes, set a default time from minTime if the date has midnight
        if (selectedDate && (style === 'time' || style === 'datetime' || style === 'both')) {
            if (!value && selectedDate.getHours() === 0 && selectedDate.getMinutes() === 0) {
                selectedDate.setHours(minTime.getHours(), minTime.getMinutes(), 0, 0)
            }
        }

        this.setState({
            selectedDate,
            configured: true,
            style,
            theme,
            dateFormat,
            minDate,
            maxDate,
            disableWeekends,
            weekendDays,
            holidays,
            timeFormat,
            minTime,
            maxTime,
            timeInterval,
            disableLunch,
            lunchStart,
            lunchMinutes,
            displayMode
        }, () => {
            if (selectedDate && !value) {
                setTimeout(() => {
                    this.props.onChange(this.formatDotNet(selectedDate, dateFormat))
                }, 500)
            }
        })
    }

    // Parse a dd/MM/yyyy config date string into a Date object
    parseConfigDate = (dateStr) => {
        if (!dateStr || typeof dateStr !== 'string') return null
        const parts = dateStr.split('/')
        if (parts.length !== 3) return null
        const day = parseInt(parts[0], 10)
        const month = parseInt(parts[1], 10) - 1
        const year = parseInt(parts[2], 10)
        if (isNaN(day) || isNaN(month) || isNaN(year)) return null
        return new Date(year, month, day)
    }

    // Parse an HH:mm config time string into a Date object (today with that time)
    parseConfigTime = (timeStr) => {
        if (!timeStr) return null
        const parts = timeStr.split(':')
        if (parts.length < 2) return null
        const date = new Date()
        date.setHours(parseInt(parts[0], 10), parseInt(parts[1], 10), 0, 0)
        return date
    }

    // Parse a value string formatted with a .NET custom format back into a Date
    parseDotNetFormat = (dateStr, format) => {
        if (!dateStr || !format) return null
        let regexStr = ''
        const groups = []
        let i = 0
        while (i < format.length) {
            const ch = format[i]
            let count = 1
            while (i + count < format.length && format[i + count] === ch) count++
            switch (ch) {
                case 'd':
                    if (count >= 3) { regexStr += '\\w+'; i += count }
                    else { regexStr += '(\\d{1,2})'; groups.push('day'); i += count }
                    break
                case 'M':
                    if (count >= 3) { regexStr += '\\w+'; i += count }
                    else { regexStr += '(\\d{1,2})'; groups.push('month'); i += count }
                    break
                case 'y':
                    if (count >= 4) { regexStr += '(\\d{4})'; groups.push('year'); i += count }
                    else if (count >= 2) { regexStr += '(\\d{2})'; groups.push('year2'); i += count }
                    else { regexStr += '\\d{1,2}'; i += count }
                    break
                case 'H': case 'h':
                    regexStr += '(\\d{1,2})'; groups.push('hour'); i += count; break
                case 'm':
                    regexStr += '(\\d{1,2})'; groups.push('minute'); i += count; break
                case 's':
                    regexStr += '(\\d{1,2})'; groups.push('second'); i += count; break
                case 't':
                    regexStr += '(\\w{1,2})'; groups.push('ampm'); i += count; break
                case 'f':
                    regexStr += '\\d{1,' + count + '}'; i += count; break
                default:
                    regexStr += ch.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); i++; break
            }
        }
        try {
            const match = dateStr.match(new RegExp('^' + regexStr + '$'))
            if (!match) return null
            const now = new Date()
            let year = now.getFullYear(), month = 0, day = 1, hour = 0, minute = 0, second = 0, isAm = null
            groups.forEach((group, idx) => {
                const val = match[idx + 1]
                switch (group) {
                    case 'year': year = parseInt(val, 10); break
                    case 'year2': year = parseInt(val, 10) + 2000; break
                    case 'month': month = parseInt(val, 10) - 1; break
                    case 'day': day = parseInt(val, 10); break
                    case 'hour': hour = parseInt(val, 10); break
                    case 'minute': minute = parseInt(val, 10); break
                    case 'second': second = parseInt(val, 10); break
                    case 'ampm': isAm = val.toUpperCase().startsWith('A'); break
                }
            })
            if (isAm !== null) {
                if (!isAm && hour < 12) hour += 12
                if (isAm && hour === 12) hour = 0
            }
            return new Date(year, month, day, hour, minute, second)
        } catch (e) {
            return null
        }
    }

    // Format a Date object using a .NET custom date/time format string
    // Supports: d/dd/ddd/dddd, M/MM/MMM/MMMM, y/yy/yyyy,
    //           H/HH (24h), h/hh (12h), m/mm, s/ss, f/ff/fff, t/tt (AM/PM)
    //           Escape with \, literal strings in 'single quotes'
    formatDotNet = (date, format) => {
        if (!date || !format) return ''
        const pad = (n, len = 2) => String(n).padStart(len, '0')
        const day = date.getDate()
        const dow = date.getDay()
        const month = date.getMonth()
        const year = date.getFullYear()
        const h24 = date.getHours()
        const h12 = h24 % 12 || 12
        const min = date.getMinutes()
        const sec = date.getSeconds()
        const ms = date.getMilliseconds()
        const ampm = h24 < 12 ? 'AM' : 'PM'
        const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
        const dayNamesShort = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
        const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
        const monthNamesShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

        let result = ''
        let i = 0
        while (i < format.length) {
            const ch = format[i]
            let count = 1
            while (i + count < format.length && format[i + count] === ch) count++
            switch (ch) {
                case 'd':
                    if (count >= 4) { result += dayNames[dow]; i += count }
                    else if (count === 3) { result += dayNamesShort[dow]; i += 3 }
                    else if (count === 2) { result += pad(day); i += 2 }
                    else { result += day; i += 1 }
                    break
                case 'M':
                    if (count >= 4) { result += monthNames[month]; i += count }
                    else if (count === 3) { result += monthNamesShort[month]; i += 3 }
                    else if (count === 2) { result += pad(month + 1); i += 2 }
                    else { result += (month + 1); i += 1 }
                    break
                case 'y':
                    if (count >= 4) { result += year; i += count }
                    else { result += pad(year % 100); i += count }
                    break
                case 'H':
                    result += count >= 2 ? pad(h24) : String(h24); i += count; break
                case 'h':
                    result += count >= 2 ? pad(h12) : String(h12); i += count; break
                case 'm':
                    result += count >= 2 ? pad(min) : String(min); i += count; break
                case 's':
                    result += count >= 2 ? pad(sec) : String(sec); i += count; break
                case 'f':
                    if (count >= 3) result += String(ms).padStart(3, '0')
                    else if (count === 2) result += String(Math.floor(ms / 10)).padStart(2, '0')
                    else result += Math.floor(ms / 100)
                    i += count; break
                case 't':
                    result += count >= 2 ? ampm : ampm[0]; i += count; break
                case '\\':
                    i++
                    if (i < format.length) { result += format[i]; i++ }
                    break
                case '\'':
                    i++
                    while (i < format.length && format[i] !== '\'') { result += format[i]; i++ }
                    if (i < format.length) i++
                    break
                default:
                    result += ch; i++; break
            }
        }
        return result
    }

    // Convert .NET custom format to date-fns format for react-datepicker display
    // Most tokens are identical; the main difference is AM/PM: .NET tt -> date-fns aa
    toDateFnsFormat = (format) => {
        return format.replace(/tt/g, 'aa').replace(/t/g, 'a')
    }

    // Returns false for dates that should be disabled (weekends)
    filterDate = (date) => {
        const { disableWeekends, weekendDays } = this.state
        if (disableWeekends && weekendDays.includes(date.getDay())) return false
        return true
    }

    // Returns false for times that fall within the lunch break
    filterTime = (time) => {
        const { disableLunch, lunchStart, lunchMinutes } = this.state
        if (!disableLunch) return true
        const timeMinutes = time.getHours() * 60 + time.getMinutes()
        const parts = lunchStart.split(':')
        const lunchStartMinutes = parseInt(parts[0], 10) * 60 + parseInt(parts[1], 10)
        const lunchEndMinutes = lunchStartMinutes + lunchMinutes
        return timeMinutes < lunchStartMinutes || timeMinutes >= lunchEndMinutes
    }

    onDateChange = (date) => {
        this.setState({ selectedDate: date })
        if (date) {
            const formatted = this.formatDotNet(date, this.state.dateFormat)
            this.props.onChange(formatted)
        }
    }

    render() {
        const {
            options = { readonly: false },
            disabled,
            required,
            readonly,
        } = this.props

        const {
            selectedDate, configured, style, theme, dateFormat,
            minDate, maxDate, timeFormat, minTime, maxTime, timeInterval,
            holidays, displayMode
        } = this.state

        if (!configured) return null

        const showDate = style === 'date' || style === 'datetime' || style === 'both'
        const showTime = style === 'time' || style === 'datetime' || style === 'both'
        const timeOnly = style === 'time'

        const displayFormat = timeOnly
            ? (timeFormat === 12 ? 'h:mm aa' : 'HH:mm')
            : this.toDateFnsFormat(dateFormat)

        const timeDisplayFormat = timeFormat === 12 ? 'h:mm aa' : 'HH:mm'

        const isReadonly = readonly || (options && options.readonly)

        return (
            <div className={`custom-date-picker-wrapper theme-${theme}`}>
                <DatePicker
                    selected={selectedDate}
                    onChange={this.onDateChange}
                    dateFormat={displayFormat}
                    timeFormat={timeDisplayFormat}
                    showTimeSelect={showTime}
                    showTimeSelectOnly={timeOnly}
                    timeIntervals={timeInterval}
                    minDate={showDate ? minDate : undefined}
                    maxDate={showDate ? maxDate : undefined}
                    excludeDates={showDate ? holidays : undefined}
                    minTime={showTime ? minTime : undefined}
                    maxTime={showTime ? maxTime : undefined}
                    filterDate={showDate ? this.filterDate : undefined}
                    filterTime={showTime ? this.filterTime : undefined}
                    disabled={disabled || isReadonly}
                    required={required}
                    timeCaption="Time"
                    className="custom-date-picker-input"
                    calendarClassName="custom-date-picker-calendar"
                    inline={displayMode === 'inline'}
                    placeholderText={timeOnly ? 'Select time...' : 'Select date...'}
                />
            </div>
        )
    }
}

if (typeof window !== 'undefined') {
    window.uStoreDucs = window.uStoreDucs || []
    window.uStoreDucs.push({
        name: 'CustomDatePicker',
        component: CustomDatePicker,
        displayName: 'Custom Date Picker',
        configSample: {
            style: "date",
            theme: "light",
            displayMode: "click",
            dateFormat: "dd/MM/yyyy",
            initialDate: "01/06/2026",
            minDate: "01/05/2026",
            maxDate: "31/07/2026",
            disableWeekends: true,
            weekendDays: [6, 0],
            holidays: ["27/04/2026", "11/05/2026"],
            timeFormat: 24,
            minTime: "09:00",
            maxTime: "17:00",
            timeInterval: 15,
            disableLunch: true,
            lunchStart: "12:00",
            lunchMinutes: 30
        },
    })
}

export default CustomDatePicker
