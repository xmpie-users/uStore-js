import React, { Component } from 'react'
import './styles/subordinate-select.scss'

class SubordinateSelect extends Component {
    constructor(props) {
        super(props)
        this.state = {
            selectTagTitles: [],
            selectTagData: {},
            selectTagDataUrl: "",
            useLastSelectOnly: false,
            selections: []
        }
    }

    componentDidMount() {
        const {uiSchema: {'ui:options': {custom}}} = this.props
        const {selectTagData, selectTagDataUrl, useLastSelectOnly} = custom
        const selectTagTitles = custom.selectTagTitles || this.generateDefaultTitles(selectTagData)

        if (selectTagDataUrl) {
            fetch(selectTagDataUrl)
                .then(response => response.json())
                .then(fetchedData => {
                    this.initializeState(selectTagTitles, fetchedData, selectTagDataUrl, useLastSelectOnly)
                })
                .catch(() => {
                    this.initializeState(selectTagTitles, selectTagData, selectTagDataUrl, useLastSelectOnly)
                })
        } else {
            this.initializeState(selectTagTitles, selectTagData, selectTagDataUrl, useLastSelectOnly)
        }
    }

    initializeState(selectTagTitles, selectTagData, selectTagDataUrl, useLastSelectOnly) {
        const {value} = this.props
        const selections = new Array(selectTagTitles.length).fill('')

        if (value) {
            const path = this.findPathToValue(selectTagData, value)
            if (path) {
                path.forEach((val, i) => { selections[i] = val })
            }
        }

        this.setState({
            selectTagTitles,
            selectTagData,
            selectTagDataUrl,
            useLastSelectOnly: !!useLastSelectOnly,
            selections
        }, () => {
            const deepest = [...selections].reverse().find(s => s !== '')
            setTimeout(() => {
                if (useLastSelectOnly) {
                    const deepestIndex = selections.lastIndexOf(deepest)
                    const nextOptions = this.getOptionsAtLevel(deepestIndex + 1)
                    if (!nextOptions || nextOptions.length === 0) {
                        console.log('SubordinateSelect onChange (init):', deepest || '')
                        this.props.onChange(deepest || '')
                    } else {
                        console.log('SubordinateSelect onChange (init):', '')
                        this.props.onChange('')
                    }
                } else {
                    console.log('SubordinateSelect onChange (init):', deepest || '')
                    this.props.onChange(deepest || '')
                }
            }, 500)
        })
    }

    generateDefaultTitles(data) {
        const titles = []
        let current = data
        let level = 1
        while (typeof current === 'object' && current !== null && !Array.isArray(current)) {
            titles.push('Selection ' + level)
            const firstKey = Object.keys(current)[0]
            if (!firstKey) break
            current = current[firstKey]
            level++
        }
        if (Array.isArray(current)) {
            titles.push('Selection ' + level)
        }
        return titles
    }

    findPathToValue(data, target) {
        if (Array.isArray(data)) {
            if (data.includes(target)) return [target]
            return null
        }
        if (typeof data === 'object' && data !== null) {
            for (const key of Object.keys(data)) {
                if (key === target) return [key]
                const subPath = this.findPathToValue(data[key], target)
                if (subPath) return [key, ...subPath]
            }
        }
        return null
    }

    getOptionsAtLevel(level) {
        const {selectTagData, selections} = this.state
        let current = selectTagData

        for (let i = 0; i < level; i++) {
            if (!selections[i] || !current[selections[i]]) return null
            current = current[selections[i]]
        }

        if (Array.isArray(current)) return current
        if (typeof current === 'object' && current !== null) return Object.keys(current)
        return null
    }

    onSelectChanged = (level, value) => {
        this.setState(prevState => {
            const selections = [...prevState.selections]
            selections[level] = value
            // Clear all selections after this level
            for (let i = level + 1; i < selections.length; i++) {
                selections[i] = ''
            }
            return {selections}
        }, () => {
            const deepest = [...this.state.selections].reverse().find(s => s !== '')
            if (this.state.useLastSelectOnly) {
                // Only report value when no further dropdowns will appear
                const nextOptions = this.getOptionsAtLevel(level + 1)
                if (!nextOptions || nextOptions.length === 0) {
                    console.log('SubordinateSelect onChange (select):', deepest || '')
                    this.props.onChange(deepest || '')
                } else if (this.props.value) {
                    console.log('SubordinateSelect onChange (select):', '')
                    this.props.onChange('')
                }
            } else {
                console.log('SubordinateSelect onChange (select):', deepest || '')
                this.props.onChange(deepest || '')
            }
        })
    }

    render() {
        const {disabled, readonly} = this.props
        const {selectTagTitles, selections} = this.state

        return (
            <div>
                <div className='subordinate-select-div'>
                    {selectTagTitles.map((title, level) => {
                        const options = this.getOptionsAtLevel(level)
                        if (!options || options.length === 0) return null

                        return (
                            <div key={level} className='subordinate-select-subdiv'>
                                <select
                                    value={selections[level] || ''}
                                    onChange={(e) => this.onSelectChanged(level, e.target.value)}
                                    disabled={disabled || readonly}
                                    className='form-control subordinate-select'
                                >
                                    <option value=''>-- Select {title} --</option>
                                    {options.map(opt => (
                                        <option key={opt} value={opt}>{opt}</option>
                                    ))}
                                </select>
                            </div>
                        )
                    })}
                </div>
            </div>
        )
    }
}

if (typeof window !== 'undefined') {
    window.uStoreDucs = window.uStoreDucs || []
    window.uStoreDucs.push({
        name: 'SubordinateSelect',
        component: SubordinateSelect,
        displayName: 'Subordinate Select',
        configSample: {
            "selectTagTitles": ["Genre","Category","Author","Title"],
            "selectTagData": {
                "Fiction": {
                    "Romance": {
                        "Rebecca Yarros": ["Fourth Wing","Onux Storm","Iron Flame","Wilder","Nova"],
                        "Navessa Allen": ["Lights Out","Caught Up","Game On"],
                        "Leigh Rivers": ["Insatiable","Voracious"]
                    },
                    "Crime & Mystery": {
                        "David Baldacci": ["Daylignt","Nash Fals","Strangers in Time","Hope Rises","The Fix","The Target","Hells Corner"],
                        "Candice Fox": ["Redbelly Crossing","Hades","Devils Kitchen"]
                    },
                    "Classic Fiction": {
                        "Emily Bronte": ["Wuthering Heights"],
                        "Fyodor Dostoyevsky": ["White Nights"],
                        "George Orwell": ["1984"],
                        "John Steinbeck": ["East of Eden"]
                    },
                    "Fantasy": {
                        "Andy Weir": ["Project Hail Mary"],
                        "Alex Aster": ["Starside","Lightlark","Nightbane"],
                        "J.R.R. Tolkien": ["The Lord of the Rings", "The Fall of Gondolin"]
                    },
                    "Manga": {
                        "Jujutsu Kaisen": ["Vol. 1", "Vol. 2"]
                    }
                },
                "Non Fiction": {
                    "Biographies": {
                        "Tom Bower": ["Betrayal"],
                        "Gisele Pelicot": ["A Hymn to Life"]
                    },
                    "History": {
                        "Stephen Fry": ["Odyssey","Mythos","Heroes"],
                        "David Mitchell": ["Unruly"]
                    },
                    "Travel": {
                        "Lonely Planet": ["Japan","Australia"],
                        "Jiawa Liu": ["7 Days a Parisian"],
                        "Robert Pirsig": ["Zen and the Art of Motorcycle Maintenance"]
                    }
                }
            },
            "selectTagDataUrl": "",
            "useLastSelectOnly": false
        },
    })
}

export default SubordinateSelect
