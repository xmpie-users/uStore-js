import React, { Component } from 'react'
import PropTypes from 'prop-types'
import './styles/cmyk-color-picker.scss'

// --- Color conversion utilities ---

function hsvToRgb(h, s, v) {
    const c = v * s
    const x = c * (1 - Math.abs(((h / 60) % 2) - 1))
    const m = v - c
    let r, g, b
    if (h < 60)       { r = c; g = x; b = 0 }
    else if (h < 120) { r = x; g = c; b = 0 }
    else if (h < 180) { r = 0; g = c; b = x }
    else if (h < 240) { r = 0; g = x; b = c }
    else if (h < 300) { r = x; g = 0; b = c }
    else               { r = c; g = 0; b = x }
    return {
        r: Math.round((r + m) * 255),
        g: Math.round((g + m) * 255),
        b: Math.round((b + m) * 255),
    }
}

function rgbToHsv(r, g, b) {
    r /= 255; g /= 255; b /= 255
    const max = Math.max(r, g, b), min = Math.min(r, g, b)
    const d = max - min
    let h = 0
    const s = max === 0 ? 0 : d / max
    const v = max
    if (d !== 0) {
        if (max === r)      h = 60 * (((g - b) / d) % 6)
        else if (max === g) h = 60 * ((b - r) / d + 2)
        else                h = 60 * ((r - g) / d + 4)
    }
    if (h < 0) h += 360
    return { h, s, v }
}

function rgbToCmyk(r, g, b) {
    const rr = r / 255, gg = g / 255, bb = b / 255
    const k = 1 - Math.max(rr, gg, bb)
    if (k >= 1) return { c: 0, m: 0, y: 0, k: 100 }
    return {
        c: Math.round(((1 - rr - k) / (1 - k)) * 100),
        m: Math.round(((1 - gg - k) / (1 - k)) * 100),
        y: Math.round(((1 - bb - k) / (1 - k)) * 100),
        k: Math.round(k * 100),
    }
}

function cmykToRgb(c, m, y, k) {
    return {
        r: Math.round(255 * (1 - c / 100) * (1 - k / 100)),
        g: Math.round(255 * (1 - m / 100) * (1 - k / 100)),
        b: Math.round(255 * (1 - y / 100) * (1 - k / 100)),
    }
}

function cmykToRgbStr(cmykStr) {
    const { c, m, y, k } = parseCmyk(cmykStr)
    const { r, g, b } = cmykToRgb(c, m, y, k)
    return `rgb(${r},${g},${b})`
}

function parseCmyk(cmykStr) {
    if (!cmykStr) return { c: 0, m: 0, y: 0, k: 0 }
    const parts = cmykStr.split(',').map(Number)
    return {
        c: isNaN(parts[0]) ? 0 : Math.max(0, Math.min(100, parts[0])),
        m: isNaN(parts[1]) ? 0 : Math.max(0, Math.min(100, parts[1])),
        y: isNaN(parts[2]) ? 0 : Math.max(0, Math.min(100, parts[2])),
        k: isNaN(parts[3]) ? 0 : Math.max(0, Math.min(100, parts[3])),
    }
}

function formatCmyk({ c, m, y, k }) {
    return `${Math.round(c)},${Math.round(m)},${Math.round(y)},${Math.round(k)}`
}

// --- Canvas dimensions ---
const SV_SIZE = 200
const HUE_BAR_WIDTH = 24
const HUE_BAR_HEIGHT = SV_SIZE

class CmykColorPicker extends Component {
    constructor(props) {
        super(props)

        this.svCanvasRef = React.createRef()
        this.hueCanvasRef = React.createRef()

        const config = this.getConfig(props)
        const currentValue = props.value || config.initialColor || '0,0,0,0'
        const cmyk = parseCmyk(currentValue)
        const rgb = cmykToRgb(cmyk.c, cmyk.m, cmyk.y, cmyk.k)
        const hsv = rgbToHsv(rgb.r, rgb.g, rgb.b)

        this.state = {
            swatches: config.swatches,
            allowCustom: config.allowCustom,
            swatchSize: config.swatchSize,
            swatchPosition: config.swatchPosition,
            swatchShape: config.swatchShape,
            selectedValue: currentValue,
            ...cmyk,
            h: hsv.h, s: hsv.s, v: hsv.v,
            draggingSV: false,
            draggingHue: false,
        }
    }

    getConfig(props) {
        const custom = props.uiSchema
            && props.uiSchema['ui:options']
            && props.uiSchema['ui:options'].custom

        return {
            swatches: (custom && custom.swatches) || [],
            allowCustom: custom ? !!custom.allowCustom : true,
            initialColor: (custom && custom.initialColor) || '0,0,0,0',
            swatchSize: (custom && custom.swatchSize) || 44,
            swatchPosition: (custom && custom.swatchPosition) || 'above',
            swatchShape: (custom && custom.swatchShape) || 'square',
        }
    }

    componentDidMount() {
        const config = this.getConfig(this.props)
        const currentValue = this.props.value || config.initialColor || '0,0,0,0'
        const cmyk = parseCmyk(currentValue)
        const rgb = cmykToRgb(cmyk.c, cmyk.m, cmyk.y, cmyk.k)
        const hsv = rgbToHsv(rgb.r, rgb.g, rgb.b)

        this.setState({
            swatches: config.swatches,
            allowCustom: config.allowCustom,
            swatchSize: config.swatchSize,
            swatchPosition: config.swatchPosition,
            swatchShape: config.swatchShape,
            selectedValue: currentValue,
            ...cmyk,
            h: hsv.h, s: hsv.s, v: hsv.v,
        }, () => {
            this.drawSVCanvas()
            this.drawHueBar()
        })

        document.addEventListener('mousemove', this.handleDocMouseMove)
        document.addEventListener('mouseup', this.handleDocMouseUp)
        document.addEventListener('touchmove', this.handleDocTouchMove, { passive: false })
        document.addEventListener('touchend', this.handleDocMouseUp)

        this.notifyChange(currentValue)
    }

    componentWillUnmount() {
        document.removeEventListener('mousemove', this.handleDocMouseMove)
        document.removeEventListener('mouseup', this.handleDocMouseUp)
        document.removeEventListener('touchmove', this.handleDocTouchMove)
        document.removeEventListener('touchend', this.handleDocMouseUp)
        clearTimeout(this._changeTimeout)
    }

    componentDidUpdate(_, prevState) {
        if (prevState.h !== this.state.h && this.state.allowCustom) {
            this.drawSVCanvas()
        }
    }

    // --- Canvas drawing ---

    drawSVCanvas() {
        const canvas = this.svCanvasRef.current
        if (!canvas) return
        const ctx = canvas.getContext('2d')
        const w = SV_SIZE, h = SV_SIZE

        // Base hue color
        const { r, g, b } = hsvToRgb(this.state.h, 1, 1)

        // Fill with white-to-hue horizontal gradient
        const gradH = ctx.createLinearGradient(0, 0, w, 0)
        gradH.addColorStop(0, '#fff')
        gradH.addColorStop(1, `rgb(${r},${g},${b})`)
        ctx.fillStyle = gradH
        ctx.fillRect(0, 0, w, h)

        // Overlay transparent-to-black vertical gradient
        const gradV = ctx.createLinearGradient(0, 0, 0, h)
        gradV.addColorStop(0, 'rgba(0,0,0,0)')
        gradV.addColorStop(1, 'rgba(0,0,0,1)')
        ctx.fillStyle = gradV
        ctx.fillRect(0, 0, w, h)
    }

    drawHueBar() {
        const canvas = this.hueCanvasRef.current
        if (!canvas) return
        const ctx = canvas.getContext('2d')
        const w = HUE_BAR_WIDTH, h = HUE_BAR_HEIGHT

        const grad = ctx.createLinearGradient(0, 0, 0, h)
        const stops = [0, 60, 120, 180, 240, 300, 360]
        stops.forEach((hue, i) => {
            const { r, g, b } = hsvToRgb(hue % 360, 1, 1)
            grad.addColorStop(i / (stops.length - 1), `rgb(${r},${g},${b})`)
        })
        ctx.fillStyle = grad
        ctx.fillRect(0, 0, w, h)
    }

    // --- Centralized state update ---

    notifyChange(value) {
        clearTimeout(this._changeTimeout)
        this._changeTimeout = setTimeout(() => {
            if (this.props.onChange) this.props.onChange(value)
        }, 500)
    }

    updateFromHSV(h, s, v) {
        const rgb = hsvToRgb(h, s, v)
        const cmyk = rgbToCmyk(rgb.r, rgb.g, rgb.b)
        const formatted = formatCmyk(cmyk)
        this.setState({ h, s, v, ...cmyk, selectedValue: formatted })
        this.notifyChange(formatted)
    }

    updateFromCMYK(cmyk) {
        const rgb = cmykToRgb(cmyk.c, cmyk.m, cmyk.y, cmyk.k)
        const hsv = rgbToHsv(rgb.r, rgb.g, rgb.b)
        const formatted = formatCmyk(cmyk)
        this.setState({ ...cmyk, h: hsv.h, s: hsv.s, v: hsv.v, selectedValue: formatted })
        this.notifyChange(formatted)
    }

    // --- SV canvas interaction ---

    getSVFromEvent(e) {
        const canvas = this.svCanvasRef.current
        if (!canvas) return null
        const rect = canvas.getBoundingClientRect()
        const clientX = e.touches ? e.touches[0].clientX : e.clientX
        const clientY = e.touches ? e.touches[0].clientY : e.clientY
        const s = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width))
        const v = Math.max(0, Math.min(1, 1 - (clientY - rect.top) / rect.height))
        return { s, v }
    }

    handleSVMouseDown = (e) => {
        if (this.isDisabled()) return
        e.preventDefault()
        this.setState({ draggingSV: true })
        const sv = this.getSVFromEvent(e)
        if (sv) this.updateFromHSV(this.state.h, sv.s, sv.v)
    }

    handleSVTouchStart = (e) => {
        if (this.isDisabled()) return
        e.preventDefault()
        this.setState({ draggingSV: true })
        const sv = this.getSVFromEvent(e)
        if (sv) this.updateFromHSV(this.state.h, sv.s, sv.v)
    }

    // --- Hue bar interaction ---

    getHueFromEvent(e) {
        const canvas = this.hueCanvasRef.current
        if (!canvas) return null
        const rect = canvas.getBoundingClientRect()
        const clientY = e.touches ? e.touches[0].clientY : e.clientY
        const ratio = Math.max(0, Math.min(1, (clientY - rect.top) / rect.height))
        return ratio * 360
    }

    handleHueMouseDown = (e) => {
        if (this.isDisabled()) return
        e.preventDefault()
        this.setState({ draggingHue: true })
        const h = this.getHueFromEvent(e)
        if (h !== null) this.updateFromHSV(h, this.state.s, this.state.v)
    }

    handleHueTouchStart = (e) => {
        if (this.isDisabled()) return
        e.preventDefault()
        this.setState({ draggingHue: true })
        const h = this.getHueFromEvent(e)
        if (h !== null) this.updateFromHSV(h, this.state.s, this.state.v)
    }

    // --- Document-level drag handlers ---

    handleDocMouseMove = (e) => {
        if (this.state.draggingSV) {
            const sv = this.getSVFromEvent(e)
            if (sv) this.updateFromHSV(this.state.h, sv.s, sv.v)
        } else if (this.state.draggingHue) {
            const h = this.getHueFromEvent(e)
            if (h !== null) this.updateFromHSV(h, this.state.s, this.state.v)
        }
    }

    handleDocTouchMove = (e) => {
        if (this.state.draggingSV || this.state.draggingHue) {
            e.preventDefault()
            this.handleDocMouseMove(e)
        }
    }

    handleDocMouseUp = () => {
        if (this.state.draggingSV || this.state.draggingHue) {
            this.setState({ draggingSV: false, draggingHue: false })
            this.handleBlur()
        }
    }

    // --- Swatch + slider handlers ---

    selectSwatch = (cmykStr) => {
        if (this.isDisabled()) return
        const cmyk = parseCmyk(cmykStr)
        this.updateFromCMYK(cmyk)
    }

    handleTypedInputChange = (channel, value) => {
        if (this.isDisabled()) return
        const numValue = Math.max(0, Math.min(100, parseInt(value, 10) || 0))
        this.updateFromCMYK({
            c: this.state.c,
            m: this.state.m,
            y: this.state.y,
            k: this.state.k,
            [channel]: numValue,
        })
    }

    handleBlur = () => {
        if (this.props.onBlur) {
            this.props.onBlur(this.props.id, this.state.selectedValue)
        }
    }

    isDisabled() {
        return this.props.disabled || this.props.readonly
            || (this.props.options && this.props.options.readonly)
    }

    // --- Render helpers ---

    renderSwatch(cmykStr, index) {
        const rgbColor = cmykToRgbStr(cmykStr)
        const isSelected = this.state.selectedValue === cmykStr
        const size = this.state.swatchSize
        const isLight = (() => {
            const { c, m, y, k } = parseCmyk(cmykStr)
            const { r, g, b } = cmykToRgb(c, m, y, k)
            return (r * 0.299 + g * 0.587 + b * 0.114) > 186
        })()

        return (
            <button
                key={index}
                type="button"
                className={`cmyk-swatch cmyk-swatch--${this.state.swatchShape}${isSelected ? ' cmyk-swatch--selected' : ''}${isLight ? ' cmyk-swatch--light' : ''}`}
                style={{ backgroundColor: rgbColor, width: size, height: size }}
                onClick={() => this.selectSwatch(cmykStr)}
                onBlur={this.handleBlur}
                disabled={this.isDisabled()}
                title={`C:${cmykStr.split(',')[0]} M:${cmykStr.split(',')[1]} Y:${cmykStr.split(',')[2]} K:${cmykStr.split(',')[3]}`}
                aria-label={`CMYK color ${cmykStr}`}
                aria-pressed={isSelected}
            />
        )
    }

    renderInput(channel, label) {
        const value = this.state[channel]
        return (
            <div className="cmyk-input" key={channel}>
                <label className="cmyk-input__label">{label}</label>
                <div className="cmyk-input__row">
                    <input
                        type="number"
                        min="0"
                        max="100"
                        value={value}
                        onChange={(e) => this.handleTypedInputChange(channel, e.target.value)}
                        onBlur={this.handleBlur}
                        disabled={this.isDisabled()}
                        className="cmyk-input__field"
                    />
                    <span className="cmyk-input__unit">%</span>
                </div>
            </div>
        )
    }

    renderVisualPicker() {
        const { h, s, v } = this.state
        // SV indicator position
        const svX = s * 100
        const svY = (1 - v) * 100
        // Hue indicator position
        const hueY = (h / 360) * 100

        return (
            <div className="cmyk-visual-picker">
                <div className="cmyk-sv-container">
                    <canvas
                        ref={this.svCanvasRef}
                        width={SV_SIZE}
                        height={SV_SIZE}
                        className="cmyk-sv-canvas"
                        onMouseDown={this.handleSVMouseDown}
                        onTouchStart={this.handleSVTouchStart}
                    />
                    <div
                        className="cmyk-sv-indicator"
                        style={{ left: `${svX}%`, top: `${svY}%` }}
                    />
                </div>
                <div className="cmyk-hue-container">
                    <canvas
                        ref={this.hueCanvasRef}
                        width={HUE_BAR_WIDTH}
                        height={HUE_BAR_HEIGHT}
                        className="cmyk-hue-canvas"
                        onMouseDown={this.handleHueMouseDown}
                        onTouchStart={this.handleHueTouchStart}
                    />
                    <div
                        className="cmyk-hue-indicator"
                        style={{ top: `${hueY}%` }}
                    />
                </div>
            </div>
        )
    }

    render() {
        const { swatches, allowCustom, swatchPosition } = this.state
        const disabled = this.isDisabled()
        const hasSwatches = swatches && swatches.length > 0

        const swatchBlock = hasSwatches && (
            <div className="cmyk-swatches">
                {swatches.map((swatch, i) => this.renderSwatch(swatch, i))}
            </div>
        )

        const customBlock = allowCustom && (
            <div className="cmyk-custom">
                {this.renderVisualPicker()}
                <div className="cmyk-inputs">
                    {this.renderInput('c', 'C')}
                    {this.renderInput('m', 'M')}
                    {this.renderInput('y', 'Y')}
                    {this.renderInput('k', 'K')}
                </div>
            </div>
        )

        return (
            <div className={`cmyk-color-picker${disabled ? ' cmyk-color-picker--disabled' : ''}`}>
                {swatchPosition === 'below' ? <>{customBlock}{swatchBlock}</> : <>{swatchBlock}{customBlock}</>}
            </div>
        )
    }
}

CmykColorPicker.propTypes = {
    value: PropTypes.string,
    onChange: PropTypes.func,
    onBlur: PropTypes.func,
    id: PropTypes.string,
    disabled: PropTypes.bool,
    readonly: PropTypes.bool,
    required: PropTypes.bool,
    options: PropTypes.object,
    uiSchema: PropTypes.object,
    jsonschema: PropTypes.object,
}

if (typeof window !== 'undefined') {
    window.uStoreDucs = window.uStoreDucs || []
    window.uStoreDucs.push({
        name: 'CmykColorPicker',
        component: CmykColorPicker,
        displayName: 'CMYK Color Picker',
        configSample: {
            swatches: ['0,0,0,0', '100,100,100,100', '100,65,0,20', '0,100,85,5', '0,50,90,0', '100,0,45,40'],
            allowCustom: true,
            initialColor: '0,0,0,0',
            swatchSize: 44,
            swatchPosition: 'above',
            swatchShape: 'square',
        },
    })
}

export default CmykColorPicker
